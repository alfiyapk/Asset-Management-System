<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Live stats queries
$totalAssets = $conn->query("SELECT COUNT(*) AS total FROM assets")->fetch_assoc()['total'];
$totalAllocations = $conn->query("SELECT COUNT(*) AS total FROM assigned_assets")->fetch_assoc()['total'];
$totalAvailable = $conn->query("SELECT COUNT(*) AS total FROM assets WHERE asset_status = 'available'") ->fetch_assoc()['total'];
$totalUnderMaintenance= $conn->query("SELECT COUNT(*) AS total FROM assets WHERE asset_status = 'under_maintenance'") ->fetch_assoc()['total'];
$pendingMaintenance = $conn->query("SELECT COUNT(*) AS total FROM maintenance_requests WHERE status = 'Pending'")->fetch_assoc()['total'];
$completedMaintenance = $conn->query("SELECT COUNT(*) AS total FROM maintenance_requests WHERE status = 'completed'")->fetch_assoc()['total'];
$totalUsers = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'user'")->fetch_assoc()['total'];
$totalAdmins = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'admin'")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard - Asset Management</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
    }

    body {
      display: flex;
      height: 100vh;
      background: #f0f2f5;
    }

    /* Sidebar */
    .sidebar {
      width: 230px;
      background: #2c3e50;
      color: white;
      padding: 20px;
    }

    .sidebar h2 {
      margin-bottom: 30px;
    }

    .sidebar a {
      display: block;
      color: white;
      text-decoration: none;
      padding: 10px 0;
      font-weight: 500;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background: #34495e;
      padding-left: 10px;
    }

    .menu-group .submenu {
      display: none;
      padding-left: 15px;
    }

    .menu-group .submenu a {
      font-size: 14px;
      color: #ddd;
      padding: 6px 0;
    }

    .menu-group .submenu a:hover {
      color: #00bcd4;
    }

    /* Main Content */
    .main-content {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }

    .topbar {
      background: #062c66ff;
      color: white;
      padding: 15px 25px;
      font-size: 18px;
      font-weight: 600;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .topbar a.logout {
      background: #e74c3c;
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
    }

    .dashboard {
      padding: 30px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 20px;
    }

    .card {
      padding: 20px;
      border-radius: 12px;
      color: white;
      font-weight: 500;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: transform 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card i {
      font-size: 26px;
      margin-bottom: 8px;
      display: block;
    }

    .card span {
      font-size: 28px;
      display: block;
      margin-bottom: 8px;
    }


.card.blue    { background: #3f51b5; } /* Total Assets */
.card.orange  { background: #ff9800; } /* Allocations */
.card.violet  { background: #4caf50; } /* Available Assets */
.card.indigo  { background: #9c27b0; } /* Under Maintenance */
.card.red     { background: #f44336; } /* Pending Maintenance */
.card.green   { background: #00c853; } /* Completed Services */
.card.purple  { background: #2196f3; } /* Total Users */
.card.teal    { background: #795548; } /* Active Admins */
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <h2>Master Admin</h2>

  <a href="admin_dashboard.php" class="active">Dashboard</a>

  <div class="menu-group">
    <a href="#" onclick="toggleMenu('assetMenu')">Asset Management ▾</a>
    <div id="assetMenu" class="submenu">
      <a href="add_asset.php">➤ Add Asset</a>
      <a href="view_assets.php">➤ Edit/Delete Asset</a>
      <a href="assign_asset.php">➤ Assign Assets</a>
    </div>
  </div>

  <div class="menu-group">
    <a href="#" onclick="toggleMenu('userMenu')">User Management ▾</a>
    <div id="userMenu" class="submenu">
      <a href="add_user.php">➤ Add User</a>
      <a href="view_users.php">➤ User Profile</a>
      <a href="manage_asset_requests.php">➤ View Asset Request</a>
      <a href="manage_maintenance_requests.php">➤ View Maintenance Request</a>
    </div>
  </div>
  <a href="request_return.php">Return Request</a>
  <a href="asset_tracking.php">Search</a>
  <a href="asset_history.php">History</a>
  <a href="maintenance_report.php">Reports</a>
  <a href="view_messages.php">Messages</a>

</div>

<!-- Main Content -->
<div class="main-content">
  <div class="topbar">
    <div>Welcome, <?php echo $_SESSION['name']; ?> | Admin Panel</div>
    <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <div class="dashboard">
  <a href="view_totalassets.php" style="text-decoration: none;">
  <div class="card blue">
    <i class="fas fa-box-open"></i>
    <span><?php echo $totalAssets; ?></span>
    Total Assets
  </div>
</a>

<a href="view_allallocation.php" style="text-decoration: none;">
    <div class="card orange">
  <i class="fas fa-people-carry-box"></i>
  <span><?php echo $totalAllocations; ?></span>
  Allocations
</div>
  </a>
  <a href="view_available.php" style="text-decoration: none;">
<div class="card violet">
  <i class="fas fa-boxes-stacked"></i>
  <span><?php echo $totalAvailable; ?></span>
  Available Assets
</div>
  </a>
  <a href="view_under_maintenance.php" style="text-decoration: none;">
<div class="card indigo">
  <i class="fas fa-screwdriver-wrench"></i>
  <span><?php echo $totalUnderMaintenance; ?></span>
  Under Maintenance
</div>
  </a>
  
  <a href="view_pendingmaintenance.php" style="text-decoration: none;">
    <div class="card red">
      <i class="fas fa-spinner"></i>
      <span><?php echo $pendingMaintenance; ?></span>
      Pending Maintenance
    </div>

    </a>
    <a href="view_completedservices.php" style="text-decoration: none;">
    <div class="card green">
      <i class="fas fa-check-circle"></i>
      <span><?php echo $completedMaintenance; ?></span>
      Completed Services
    </div>
  </a>
  <a href="view_totalusers.php" style="text-decoration: none;">
    <div class="card purple">
      <i class="fas fa-users"></i>
      <span><?php echo $totalUsers; ?></span>
      Total Users
    </div>
  </a>
  <a href="view_admin.php" style="text-decoration: none;">
    <div class="card teal">
      <i class="fas fa-user-shield"></i>
      <span><?php echo $totalAdmins; ?></span>
      Active Admins
    </div>
  </a>
  </div>
</div>

<script>
  function toggleMenu(id) {
    const submenu = document.getElementById(id);
    submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
  }
</script>

</body>
</html>
