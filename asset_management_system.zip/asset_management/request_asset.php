<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $asset_name = trim($_POST['asset_name']);
    $description = trim($_POST['description']);

    $stmt = $conn->prepare("INSERT INTO asset_requests (user_id, asset_name, description) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $asset_name, $description);
    
    if ($stmt->execute()) {
        echo "<script>alert('✅ Asset request submitted successfully.'); window.location.href='user_dashboard.php';</script>";
    } else {
        echo "<script>alert('❌ Failed to submit request.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Request Asset</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <style>
        body {
            background: #0f172a;
            color: white;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
        }
        .form-box {
            background: rgba(255,255,255,0.06);
            padding: 30px;
            border-radius: 16px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(12px);
        }
        h2 {
            text-align: center;
            color: #38bdf8;
        }
        label {
            margin-top: 15px;
            display: block;
            color: #cbd5e1;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            margin-top: 6px;
            border-radius: 10px;
            border: none;
            font-size: 1em;
            background: rgba(255,255,255,0.15);
            color: white;
        }
        input[type="submit"] {
            margin-top: 20px;
            background: linear-gradient(to right, #22c55e, #16a34a);
            cursor: pointer;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background: linear-gradient(to right, #15803d, #14532d);
        }
        .back {
            text-align: center;
            margin-top: 15px;
        }
        .back a {
            color: #60a5fa;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>📥 Request New Asset</h2>
        <form method="POST">
            <label>Asset Name:</label>
            <input type="text" name="asset_name" required>

            <label>Description:</label>
            <textarea name="description" rows="4" required></textarea>

            <input type="submit" value="Submit Request">
        </form>

        <div class="back">
            <a href="user_dashboard.php">⬅ Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
