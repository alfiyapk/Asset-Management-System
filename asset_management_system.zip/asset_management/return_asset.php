
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db.php';

// ✅ Only users can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// ✅ Handle asset return request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['asset_id'])) {
    $asset_id = intval($_POST['asset_id']);

    // 🔍 Step 1: Get assigned_date
    $getAssign = $conn->prepare("SELECT assigned_date FROM assigned_assets WHERE user_id = ? AND asset_id = ?");
    $getAssign->bind_param("ii", $user_id, $asset_id);
    $getAssign->execute();
    $getAssign->bind_result($assigned_date);
    $getAssign->fetch();
    $getAssign->close();

    if (!$assigned_date) {
        echo "<script>alert('❌ Error: Assigned date not found.'); window.location.href='user_dashboard.php';</script>";
        exit();
    }

    // ✅ Step 2: Insert into returned_assets table
    $insert = $conn->prepare("INSERT INTO returned_assets (user_id, asset_id, assigned_at, returned_at)
                              VALUES (?, ?, ?, NOW())");
    $insert->bind_param("iis", $user_id, $asset_id, $assigned_date);

    // ✅ Step 3: Delete from assigned_assets
    $delete = $conn->prepare("DELETE FROM assigned_assets WHERE user_id = ? AND asset_id = ?");
    $delete->bind_param("ii", $user_id, $asset_id);

    // ✅ Step 4: Update asset status to 'Available'
    $update = $conn->prepare("UPDATE assets SET asset_status = 'Available' WHERE asset_id = ?");
    $update->bind_param("i", $asset_id);

    // ✅ Execute all
    if ($insert->execute() && $delete->execute() && $update->execute()) {
        echo "<script>alert('✅ Asset successfully returned!'); window.location.href='user_dashboard.php';</script>";
        exit();
    } else {
        echo "<script>alert('❌ Failed to return asset.');</script>";
    }
}

// ✅ Fetch assigned assets
$stmt = $conn->prepare("SELECT a.asset_id, a.asset_name 
                        FROM assigned_assets aa
                        JOIN assets a ON aa.asset_id = a.asset_id
                        WHERE aa.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$assets = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Return Asset</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      padding: 50px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      font-family: 'Poppins', sans-serif;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .container {
      background: rgba(255,255,255,0.05);
      padding: 30px;
      border-radius: 16px;
      width: 100%;
      max-width: 450px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
      backdrop-filter: blur(12px);
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #38bdf8;
    }

    label {
      display: block;
      margin-bottom: 10px;
    }

    select, input[type="submit"] {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 10px;
      border: none;
      font-size: 1em;
    }

    select {
      background: rgba(255,255,255,0.1);
      color: #fff;
    }

    select option {
      color: #000;
    }

    input[type="submit"] {
      background: linear-gradient(to right, #22c55e, #16a34a);
      color: white;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
    }

    input[type="submit"]:hover {
      background: linear-gradient(to right, #15803d, #14532d);
    }

    .back {
      text-align: center;
    }

    .back a {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 500;
    }

    .back a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>📤 Return Your Asset</h2>

    <form method="POST">
      <label for="asset_id">Select Assigned Asset:</label>
      <select name="asset_id" id="asset_id" required>
        <option value="">-- Choose Asset --</option>
        <?php while ($row = $assets->fetch_assoc()) { ?>
          <option value="<?= $row['asset_id']; ?>"><?= htmlspecialchars($row['asset_name']); ?></option>
        <?php } ?>
      </select>

      <input type="submit" value="Return Asset">
    </form>

    <div class="back">
      <a href="user_dashboard.php">⬅ Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
