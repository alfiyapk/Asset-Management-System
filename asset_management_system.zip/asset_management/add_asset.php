<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['asset_name'];
    $type = $_POST['asset_type'];
    $status = "Available"; // default internally
$sql = "INSERT INTO assets (asset_name, asset_type, asset_status, asset_description) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $type, $status, $desc);
    $desc = $_POST['asset_description'];
    
    if ($stmt->execute()) {
        echo "<script>alert('✅ Asset added successfully!'); window.location.href='admin_dashboard.php';</script>";
        exit();
    } else {
        echo "<script>alert('❌ Error: " . $stmt->error . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Asset - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(to bottom right, #001f3f, #003366);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
    }

    .form-container {
      background: rgba(255, 255, 255, 0.07);
      backdrop-filter: blur(10px);
      padding: 40px;
      border-radius: 20px;
      width: 100%;
      max-width: 500px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.35);
      border: 1px solid rgba(255,255,255,0.1);
    }

    .form-container h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #00d4ff;
      font-weight: 600;
    }

    label {
      display: block;
      margin-top: 15px;
      font-weight: 500;
      color: rgba(244, 236, 236, 0.79);
    }

    input[type="text"],
    select,
    textarea {
      width: 100%;
      padding: 12px;
      margin-top: 6px;
      border-radius: 8px;
      font-size: 15px;
      background: rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #000; /* black input text */
    }

    input[type="text"]:focus,
    select:focus,
    textarea:focus {
      outline: none;
      background: rgb(246, 244, 244);
      box-shadow: 0 0 0 2px #00d4ff;
    }

    select {
      appearance: none;
      background-image: url("data:image/svg+xml;charset=UTF-8,%3Csvg width='14' height='10' viewBox='0 0 14 10' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7 10L0.937822 0.25L13.0622 0.25L7 10Z' fill='%23000000'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 12px center;
      background-size: 12px;
    }

    textarea {
      resize: vertical;
      min-height: 80px;
    }

    textarea::placeholder,
    input::placeholder {
      color: #000; /* placeholder in black */
      opacity: 1;
    }

    .btn-submit {
      width: 100%;
      margin-top: 25px;
      background-color: #ff7f50;
      color: white;
      border: none;
      padding: 14px;
      font-size: 1em;
      font-weight: bold;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .btn-submit:hover {
      background-color: #ff5e1a;
    }

    .back-link {
      margin-top: 25px;
      text-align: center;
    }

    .back-link a {
      color: #00d4ff;
      font-weight: 500;
      text-decoration: none;
    }

    .back-link a:hover {
      text-decoration: underline;
    }

    @media (max-width: 550px) {
      .form-container {
        padding: 30px 20px;
        margin: 20px;
      }
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2><i class="fas fa-plus-circle"></i> Add New Asset</h2>

    <form method="POST">
      <label for="asset_name">Asset Name</label>
      <input type="text" name="asset_name" id="asset_name" required>

      <label for="asset_type">Asset Type</label>
      <input type="text" name="asset_type" id="asset_type" required>
   

      <label for="asset_description">Description</label>
      <textarea name="asset_description" id="asset_description" placeholder="Enter optional description..."></textarea>

      <button type="submit" class="btn-submit">➕ Add Asset</button>
    </form>

    <div class="back-link">
      <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
  </div>

</body>
</html>
