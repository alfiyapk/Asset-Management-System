<?php 
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'];

// User Stats
$assignedAssets = $conn->query("SELECT COUNT(*) AS total FROM assigned_assets WHERE user_id = $user_id")->fetch_assoc()['total'];
$maintenanceRequests = $conn->query("SELECT COUNT(*) AS total FROM maintenance_requests WHERE user_id = $user_id")->fetch_assoc()['total'];
$pendingRequests = $conn->query("SELECT COUNT(*) AS total FROM maintenance_requests WHERE user_id = $user_id AND status = 'Pending'")->fetch_assoc()['total'];
$resolvedRequests = $conn->query("SELECT COUNT(*) AS total FROM maintenance_requests WHERE user_id = $user_id AND status = 'completed'")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>User Dashboard - Asset Management</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }

    body {
      display: flex;
      height: 100vh;
      background: #f4f6f8;
    }

    .sidebar {
      width: 230px;
      background: #2c3e50;
      color: white;
      padding: 20px;
      height: 100vh;
    }

    .sidebar h2 {
      margin-bottom: 30px;
      font-size: 22px;
      text-align: center;
      color: #ecf0f1;
    }

    .sidebar a {
      display: flex;
      align-items: center;
      color: white;
      text-decoration: none;
      padding: 10px 12px;
      font-weight: 500;
      border-radius: 5px;
      margin-bottom: 5px;
      transition: background 0.3s;
    }

    .sidebar a i {
      margin-right: 10px;
      width: 20px;
      text-align: center;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background: #34495e;
    }

    .main-content {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }

    .topbar {
      background:#062c66ff ;
      color: white;
      padding: 15px 25px;
      font-size: 18px;
      font-weight: 600;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .topbar a.logout {
      background: #e74c3c;
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s;
    }

    .topbar a.logout:hover {
      background: #c0392b;
    }

    .dashboard {
      padding: 30px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 20px;
    }

    .card {
      padding: 20px;
      border-radius: 12px;
      color: white;
      font-weight: 500;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      transition: transform 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card.blue    { background: #2980b9; }
    .card.orange  { background: #e67e22; }
    .card.red     { background: #c0392b; }
    .card.green   { background: #27ae60; }

    .card i {
      font-size: 26px;
      margin-bottom: 10px;
      display: block;
    }

    .card span {
      font-size: 26px;
      display: block;
      margin-bottom: 5px;
    }

    .card small {
      font-size: 14px;
      opacity: 0.85;
    }

    @media (max-width: 768px) {
      .dashboard {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      }

      .topbar {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h2>User Panel</h2>
    <a href="user_dashboard.php" class="active"><i class="fas fa-chart-line"></i> Dashboard</a>
    <a href="request_maintenance.php"><i class="fas fa-tools"></i> Request Maintenance</a>
    <a href="view_maintenance_status.php"><i class="fas fa-list-check"></i> My Maintenance</a>
    <a href="request_asset.php"><i class="fas fa-laptop"></i> Request Asset</a>
    <a href="view_requests_status.php"><i class="fas fa-clipboard-list"></i> My Requests</a>
    <a href="return_asset.php"><i class="fas fa-undo"></i> Return Asset</a>
    <a href="notification.php"><i class="fas fa-bell"></i> Notifications</a>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="topbar">
      <div>Welcome, <?php echo htmlspecialchars($name); ?> | User Dashboard</div>
      <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="dashboard">
        <a href="assigned_assets.php" style="text-decoration: none;">
      <div class="card blue">
       
        <i class="fas fa-box-open"></i>
        <span><?php echo $assignedAssets; ?></span>
        <small>Assigned Assets</small>
      </div>
  </a>
  <a href="view_maintenance_status.php" style="text-decoration: none;">
      <div class="card orange">
        <i class="fas fa-tools"></i>
        <span><?php echo $maintenanceRequests; ?></span>
        <small>Maintenance Requests</small>
      </div>
  </a>
  <a href="pending_requests.php" style="text-decoration: none;">
      <div class="card red">
        <i class="fas fa-exclamation-circle"></i>
        <span><?php echo $pendingRequests; ?></span>
        <small>Pending Requests</small>
      </div>
  </a>
   <a href="resolved_requests.php" style="text-decoration: none;">
      <div class="card green">
        <i class="fas fa-check-circle"></i>
        <span><?php echo $resolvedRequests; ?></span>
        <small>Resolved Requests</small>
      </div>
  </a>
    </div>
  </div>

</body>
</html>
