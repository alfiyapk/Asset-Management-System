<?php
$servername = "localhost";
$username = "root";         // Default for XAMPP
$password = "";             // Default is empty for root in XAMPP
$dbname = "asset_management";  // Make sure this matches your DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
