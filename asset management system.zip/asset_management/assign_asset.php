<?php
session_start();
include 'db.php';

// Only admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle asset assignment
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $asset_id = $_POST['asset_id'];

    $assign = $conn->prepare("INSERT INTO assigned_assets (user_id, asset_id) VALUES (?, ?)");
    $assign->bind_param("ii", $user_id, $asset_id);

    $update_asset = $conn->prepare("UPDATE assets SET asset_status='Allocated' WHERE asset_id=?");
    $update_asset->bind_param("i", $asset_id);

    if ($assign->execute() && $update_asset->execute()) {
        echo "<script>alert('✅ Asset successfully assigned!'); window.location.href='admin_dashboard.php';</script>";
    } else {
        echo "<script>alert('❌ Error in assignment.');</script>";
    }
}

// Get users and available assets
$users = $conn->query("SELECT user_id, name FROM users WHERE role='user'");
$assets = $conn->query("SELECT asset_id, asset_name FROM assets WHERE asset_status='Available'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Assign Asset</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .form-container {
      background: rgba(255, 255, 255, 0.06);
      backdrop-filter: blur(12px);
      padding: 40px;
      border-radius: 18px;
      width: 95%;
      max-width: 420px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
      border: 1px solid rgba(255,255,255,0.1);
    }

    h2 {
      text-align: center;
      color: #38bdf8;
      font-size: 1.9em;
      margin-bottom: 30px;
    }

    label {
      display: block;
      margin-top: 18px;
      color: #cbd5e1;
      font-weight: 500;
    }

    select {
      width: 100%;
      padding: 12px;
      margin-top: 8px;
      border-radius: 10px;
      border: 1px solid rgba(255,255,255,0.2);
      background: rgba(255,255,255,0.15);
      color: #fff;
      font-size: 1em;
      backdrop-filter: blur(8px);
    }

    select option {
      background: #1e293b;
      color: #f1f5f9;
    }

    select:focus {
      outline: none;
      border-color: #38bdf8;
    }

    input[type="submit"] {
      width: 100%;
      margin-top: 30px;
      background: linear-gradient(to right, #38bdf8, #2563eb);
      color: white;
      border: none;
      padding: 14px;
      font-size: 1em;
      font-weight: 600;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    input[type="submit"]:hover {
      background: linear-gradient(to right, #2563eb, #1e40af);
    }

    .back {
      margin-top: 20px;
      text-align: center;
    }

    .back a {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 500;
    }

    .back a:hover {
      text-decoration: underline;
    }

    @media (max-width: 500px) {
      .form-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>📦 Assign Asset</h2>
    <form method="POST">
      <label for="user_id">Select User</label>
      <select name="user_id" id="user_id" required>
        <option value="">-- Choose User --</option>
        <?php while ($user = $users->fetch_assoc()) { ?>
          <option value="<?= $user['user_id']; ?>"><?= htmlspecialchars($user['name']); ?></option>
        <?php } ?>
      </select>

      <label for="asset_id">Select Asset</label>
      <select name="asset_id" id="asset_id" required>
        <option value="">-- Choose Asset --</option>
        <?php while ($asset = $assets->fetch_assoc()) { ?>
          <option value="<?= $asset['asset_id']; ?>"><?= htmlspecialchars($asset['asset_name']); ?></option>
        <?php } ?>
      </select>

      <input type="submit" value="Assign Asset">
    </form>

    <div class="back">
      <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
