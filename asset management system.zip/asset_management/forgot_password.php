<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'db.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$response = ""; // Feedback message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if email exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $token = bin2hex(random_bytes(32));

        // ✅ Change this to your actual domain or localhost path
        $url = "http://localhost/asset_management/reset_password.php?token=$token";

        // Save token to DB
        $stmt = $conn->prepare("INSERT INTO password_resets (email, token) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();

        // Send Email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'your mail @gmail.com';
            $mail->Password   = 'app password'; // App password
            $mail->SMTPSecure = 'tls';
            $mail->Port       = port;

            $mail->setFrom('your mail   @gmail.com', 'Asset Management');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body    = "Hello,<br><br>Click the link below to reset your password:<br><br>
                              <a href='$url'>$url</a><br><br>This link will expire after use.";

            $mail->send();
            $response = "✅ Password reset link has been sent to your email.";
        } catch (Exception $e) {
            $response = "❌ Mail Error: " . $mail->ErrorInfo;
        }
    } else {
        $response = "❌ Email not found in our system.";
    }
}
?>

<!-- ✅ Response Display Page (styled) -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Forgot Password - Asset Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: #0e1a2b;
      color: #fff;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .message-box {
      background: rgba(255, 255, 255, 0.05);
      padding: 40px 30px;
      border-radius: 16px;
      width: 100%;
      max-width: 400px;
      text-align: center;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .message-box h2 {
      margin-bottom: 20px;
      color: #00d4ff;
    }

    .message-box p {
      font-size: 15px;
      color: #ccc;
    }

    .message-box a {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 16px;
      background-color: #ff814c;
      color: white;
      border-radius: 8px;
      text-decoration: none;
      transition: background 0.3s;
    }

    .message-box a:hover {
      background-color: #ff5c1a;
    }
  </style>
</head>
<body>
  <div class="message-box">
    <h2>Password Reset</h2>
    <p><?php echo $response; ?></p>
    <a href="login.html">Back to Login</a>
  </div>
</body>
</html>
