<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications - Asset System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #0f172a, #1e293b);
            font-family: 'Poppins', sans-serif;
            color: #fff;
            padding: 30px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: rgba(255,255,255,0.05);
            padding: 30px;
            border-radius: 16px;
            backdrop-filter: blur(12px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #38bdf8;
        }

        .notification {
            background: rgba(255,255,255,0.07);
            padding: 18px 20px;
            border-left: 5px solid #38bdf8;
            margin-bottom: 15px;
            border-radius: 10px;
        }

        .status {
            font-weight: bold;
            display: inline-block;
            padding: 5px 10px;
            border-radius: 8px;
            text-transform: capitalize;
        }

        .status.in_progress {
            background: #3b82f6;
            color: #fff;
        }

        .status.resolved {
            background: #10b981;
            color: #fff;
        }

        .timestamp {
            font-size: 0.9em;
            color: #cbd5e1;
            margin-top: 5px;
        }

        .back {
            text-align: center;
            margin-top: 30px;
        }

        .back a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            background: #2563eb;
            padding: 10px 20px;
            border-radius: 8px;
            transition: background 0.3s ease;
        }

        .back a:hover {
            background: #1e3a8a;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>🔔 Notifications</h2>

    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="notification">
                <div><?php echo $row['message']; ?></div>
                <div class="timestamp"><?php echo date("d M Y, h:i A", strtotime($row['created_at'])); ?></div>
            </div>
        <?php } ?>
    <?php else: ?>
        <p>No notifications yet.</p>
    <?php endif; ?>

    <div class="back">
        <a href="user_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
</div>
</body>
</html>
