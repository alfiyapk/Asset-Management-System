<?php
 require 'PHPMailer/src/PHPMailer.php';
 require 'PHPMailer/src/SMTP.php';
 require 'PHPMailer/src/Exception.php';
 
 use PHPMailer\PHPMailer\PHPMailer;
 use PHPMailer\PHPMailer\Exception;
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
  $request_id = $_POST['request_id'];
  $new_status = $_POST['status'];

  // Update maintenance request status
  $update = $conn->prepare("UPDATE maintenance_requests SET status = ? WHERE request_id = ?");
  $update->bind_param("si", $new_status, $request_id);
  $update->execute();

  // Fetch user email, name, and asset
  $stmt = $conn->prepare("SELECT u.user_id, u.email, u.name, a.asset_name FROM maintenance_requests m 
                          JOIN users u ON m.user_id = u.user_id 
                          JOIN assets a ON m.asset_id = a.asset_id 
                          WHERE m.request_id = ?");
  $stmt->bind_param("i", $request_id);
  $stmt->execute();
  $stmt->bind_result($user_id, $email, $name, $asset_name);
  $stmt->fetch();
  $stmt->close();

  $lower_new_status = strtolower($new_status);

  // Insert notification
  $notif_msg = "Maintenance status for your asset '" . $asset_name . "' is now '$new_status'.";
  $notif = $conn->prepare("INSERT INTO notifications (user_id, message, status) VALUES (?, ?, ?)");
  $notif->bind_param("iss", $user_id, $notif_msg, $lower_new_status);
  $notif->execute();

  // Send email only if status is "completed"
  if (strtolower($new_status) == 'completed') {
      $mail = new PHPMailer(true);
      try {
          // SMTP settings
          $mail->isSMTP();
          $mail->Host       = 'smtp.gmail.com';
          $mail->SMTPAuth   = true;
          $mail->Username   = 'alfiyapk84@gmail.com';      // Your Gmail
          $mail->Password   = 'hlctmiskntvvixhf';          // App password
          $mail->SMTPSecure = 'tls';
          $mail->Port       = 587;

          // Email content
          $mail->setFrom('alfiyapk84@gmail.com', 'Asset Management System');
          $mail->addAddress($email, $name);
          $mail->isHTML(true);
          $mail->Subject = "Maintenance Request Status Updated";
          $mail->Body    = "Dear $name,<br><br>Your maintenance request for <b>'$asset_name'</b> has been updated to: <b>" . ucwords(str_replace("_", " ", $new_status)) . "</b>.<br><br>Regards,<br>Asset Management Team";
          $mail->AltBody = "Dear $name,\n\nYour maintenance request for '$asset_name' has been updated to: " . ucwords(str_replace("_", " ", $new_status)) . ".\n\nRegards,\nAsset Management Team";

          $mail->send();
      } catch (Exception $e) {
          echo "Mailer Error: {$mail->ErrorInfo}";
      }
  }
}


// Fetch maintenance requests
$sql = "SELECT m.*, u.name AS user_name, a.asset_name 
        FROM maintenance_requests m 
        JOIN users u ON m.user_id = u.user_id 
        JOIN assets a ON m.asset_id = a.asset_id
        ORDER BY m.request_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Maintenance Requests</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      padding: 30px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
    }

    .container {
      max-width: 1150px;
      margin: auto;
      background: rgba(255,255,255,0.05);
      border-radius: 16px;
      padding: 30px;
      backdrop-filter: blur(10px);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #38bdf8;
      font-size: 2rem;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      border-radius: 12px;
      overflow: hidden;
      margin-top: 10px;
    }

    th, td {
      padding: 14px 16px;
      text-align: center;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    th {
      background-color: #2563eb;
      color: #fff;
      font-weight: 600;
      text-transform: uppercase;
    }

    tr:hover {
      background-color: rgba(255, 255, 255, 0.03);
    }

    select {
      padding: 8px 12px;
      border-radius: 8px;
      border: none;
      background: #fff;
      font-weight: 500;
      font-size: 0.95em;
    }

    .update-btn {
      background-color: #22c55e;
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: background 0.3s ease;
    }

    .update-btn:hover {
      background-color: #16a34a;
    }

    .status {
      font-weight: bold;
      text-transform: capitalize;
      padding: 6px 10px;
      border-radius: 10px;
      display: inline-block;
    }

    .pending {
      background-color: #facc15;
      color: #1f2937;
    }

    .in_progress {
      background-color: #3b82f6;
      color: #fff;
    }

    .completed {
      background-color: #10b981;
      color: #fff;
    }

    .back {
      text-align: center;
      margin-top: 30px;
    }

    .back a {
      display: inline-block;
      padding: 12px 20px;
      background: linear-gradient(to right, #3b82f6, #1e40af);
      color: #fff;
      border-radius: 10px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s ease;
    }

    .back a:hover {
      background: linear-gradient(to right, #1e40af, #1e3a8a);
    }

    @media (max-width: 768px) {
      table {
        font-size: 0.85rem;
      }

      th, td {
        padding: 10px;
      }

      .update-btn {
        padding: 6px 10px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>🔧 Manage Maintenance Requests</h2>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Asset</th>
          <th>Issue</th>
          <th>Change Status</th>
          <th>Requested On</th>
          <th>Current Status</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
          <tr>
            <td><?= $row['request_id']; ?></td>
            <td><?= htmlspecialchars($row['user_name']); ?></td>
            <td><?= htmlspecialchars($row['asset_name']); ?></td>
            <td><?= htmlspecialchars($row['issue_description']); ?></td>
            <td>
              <form method="POST" style="display:flex; gap:10px; justify-content:center; align-items:center;">
                <input type="hidden" name="request_id" value="<?= $row['request_id']; ?>">
                <select name="status" required>
                  <option value="pending" <?= $row['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                  <option value="in_progress" <?= $row['status'] == 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                  <option value="completed" <?= $row['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
                </select>
                <button type="submit" name="update_status" class="update-btn">Update</button>
              </form>
            </td>
            <td><?= date("d M Y, h:i A", strtotime($row['request_date'])); ?></td>
            <td>
              <span class="status <?= $row['status']; ?>">
                <?= ucwords(str_replace('_', ' ', $row['status'])); ?>
              </span>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>

    <div class="back">
      <a href="admin_dashboard.php">⬅ Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
