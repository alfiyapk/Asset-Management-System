<?php
$to = "alfiyapk84@gmail.com";
$subject = "Test Email from PHP";
$message = "Hello, this is a test email.";
$headers = "From:nahalafathima2005@gmail.com";

if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully!";
} else {
    echo "Email sending failed.";
}
?>
