
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db.php';

// ✅ User access check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// ✅ Fetch assigned assets (with assigned_date from assigned_assets table)
$sql = "SELECT a.asset_id, a.asset_name, a.asset_type, aa.assigned_date
        FROM assets a
        JOIN assigned_assets aa ON a.asset_id = aa.asset_id
        WHERE aa.user_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Assigned Assets</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      padding: 40px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
      min-height: 100vh;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    h2 {
      text-align: center;
      font-size: 1.8em;
      color: #38bdf8;
      margin-bottom: 25px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 20px;
    }

    th, td {
      padding: 14px 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      text-align: center;
    }

    th {
      background-color: #2563eb;
      color: white;
      font-weight: 600;
      text-transform: uppercase;
    }

    td {
      color: #e2e8f0;
    }

    tr:hover {
      background-color: rgba(255, 255, 255, 0.05);
    }

    .back {
      text-align: center;
      margin-bottom: 20px;
    }

    .back a {
      color: #38bdf8;
      text-decoration: none;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: 8px;
      border: 1px solid #38bdf8;
      transition: 0.3s;
    }

    .back a:hover {
      background-color: #38bdf8;
      color: #0f172a;
    }

    .muted {
      color: #9ca3af;
      font-style: italic;
    }

    @media (max-width: 768px) {
      table, th, td {
        font-size: 0.9em;
      }

      .container {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>📋 My Assigned Assets</h2>


    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Asset Name</th>
          <th>Type</th>
          <th>Assigned Date</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['asset_id']) ?></td>
              <td><?= htmlspecialchars($row['asset_name']) ?></td>
              <td><?= htmlspecialchars($row['asset_type']) ?></td>
              <td>
                <?= !empty($row['assigned_date']) ? date("d M Y", strtotime($row['assigned_date'])) : '<span class="muted">Not Assigned</span>' ?>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="4" class="muted">No assets assigned yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div style="margin-top:40px; text-align:center;">
    <a href="user_dashboard.php" 
       style="background:#2563eb; color:#fff; padding:10px 16px; border-radius:8px; 
              text-decoration:none; font-weight:600; transition:0.3s;">
      ⬅ Back to Dashboard
    </a>
  </div>
</body>
</html>
