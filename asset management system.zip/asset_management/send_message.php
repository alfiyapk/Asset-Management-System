<?php
// send_message.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST["name"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // Option 1: Save to database
    include 'db.php';
    $stmt = $conn->prepare("INSERT INTO contactmessages (name, email, message, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("sss", $name, $email, $message);
    
    if ($stmt->execute()) {
        echo "<script>alert('Message sent successfully!'); window.location.href='contact.html';</script>";
    } else {
        echo "<script>alert('Something went wrong. Try again.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();

    // Option 2 (alternative): Email instead of DB
    /*

    $to = "your_admin_email@example.com";
    $subject = "New Contact Message";
    $body = "Name: $name\nEmail: $email\nMessage:\n$message";
    $headers = "From: $email";

    if (mail($to, $subject, $body, $headers)) {
        echo "<script>alert('Message sent!'); window.location.href='contact.html';</script>";
    } else {
        echo "<script>alert('Mail failed.'); window.history.back();</script>";
    }
    */
} else {
    header("Location: contact.html");
    exit();
}
