<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Fetch contact messages
$result = $conn->query("SELECT * FROM contactmessages ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Messages - Admin Panel</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      display: flex;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
    }

    .sidebar {
      width: 230px;
      background: rgba(255, 255, 255, 0.05);
      padding: 30px 20px;
      height: 100vh;
      backdrop-filter: blur(10px);
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
    }

    .sidebar h2 {
      margin-bottom: 30px;
      font-size: 1.6em;
      color: #38bdf8;
    }

    .sidebar a {
      display: block;
      color: #fff;
      text-decoration: none;
      padding: 12px 10px;
      margin: 8px 0;
      border-radius: 8px;
      transition: background 0.3s;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background-color: #2563eb;
    }

    .main-wrapper {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }

    .topbar {
      background: rgba(255, 255, 255, 0.05);
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 15px 30px;
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    .topbar a.logout {
      background: #e74c3c;
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s ease;
    }

    .topbar a.logout:hover {
      background: #c0392b;
    }

    .main-content {
      flex: 1;
      padding: 30px;
      overflow-y: auto;
    }

    h1 {
      font-size: 1.8rem;
      margin-bottom: 25px;
      color: #38bdf8;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    }

    th, td {
      padding: 14px 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      text-align: left;
    }

    th {
      background-color: #2563eb;
      color: #fff;
      text-transform: uppercase;
      font-weight: 600;
    }

    td {
      color: #e2e8f0;
    }

    tr:hover {
      background-color: rgba(255, 255, 255, 0.04);
    }

    .no-data {
      padding: 20px;
      background: rgba(255, 99, 71, 0.1);
      color: #f87171;
      text-align: center;
      font-weight: bold;
      border-radius: 10px;
    }

    @media (max-width: 768px) {
      .sidebar {
        display: none;
      }

      .topbar {
        justify-content: center;
      }

      .main-content {
        padding: 20px;
      }

      table {
        font-size: 0.9em;
      }
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="view_assets.php">Asset Management</a>
    <a href="view_users.php">User Management</a>
    <a href="manage_maintenance_requests.php">Maintenance</a>
    <a href="asset_history.php">Reports</a>
    <a href="view_messages.php" class="active">Messages</a>
  </div>

  <!-- Main Wrapper -->
  <div class="main-wrapper">
    <!-- Topbar -->
    <div class="topbar">
      <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
      <h1>📨 Contact Messages</h1>

      <?php if ($result->num_rows > 0): ?>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Sender</th>
              <th>Email</th>
              <th>Message</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php $i = 1; while ($row = $result->fetch_assoc()): ?>
              <tr>
                <td><?= $i++; ?></td>
                <td><?= htmlspecialchars($row['name']); ?></td>
                <td><?= htmlspecialchars($row['email']); ?></td>
                <td><?= nl2br(htmlspecialchars($row['message'])); ?></td>
                <td><?= date("d M Y, h:i A", strtotime($row['created_at'])); ?></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
        <div style="margin-top:40px; text-align:center;">
    <a href="admin_dashboard.php" 
       style="background:#2563eb; color:#fff; padding:10px 16px; border-radius:8px; 
              text-decoration:none; font-weight:600; transition:0.3s;">
      ⬅ Back to Dashboard
    </a>
  </div>
      <?php else: ?>
        <div class="no-data">No messages received yet.</div>
      <?php endif; ?>
    </div>
  </div>

</body>
</html>
