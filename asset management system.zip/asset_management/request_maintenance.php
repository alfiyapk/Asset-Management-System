
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db.php';

// ✅ Only users can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// ✅ Fetch assets assigned to this user
$stmt = $conn->prepare("SELECT a.asset_id, a.asset_name 
                        FROM assigned_assets aa
                        JOIN assets a ON aa.asset_id = a.asset_id
                        WHERE aa.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$assets = $stmt->get_result();

// ✅ Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['asset_id'], $_POST['issue_description'])) {
        $asset_id = intval($_POST['asset_id']);
        $issue = trim($_POST['issue_description']);

        if ($issue === '') {
            echo "<script>alert('Issue description cannot be empty');</script>";
        } else {
            // ✅ Insert maintenance request
            $insert = $conn->prepare("INSERT INTO maintenance_requests 
                                      (user_id, asset_id, issue_description, status, request_date, action_status) 
                                      VALUES (?, ?, ?, 'pending', NOW(), 'pending')");

            if (!$insert) {
                die("SQL Prepare failed: " . $conn->error);
            }

            $insert->bind_param("iis", $user_id, $asset_id, $issue);
            if ($insert->execute()) {
                header("Location: user_dashboard.php?status=success");
                exit();
            } else {
                echo "Error executing insert: " . $insert->error;
            }
        }
    } else {
        echo "Invalid form submission.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Request Maintenance</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
      padding: 50px 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }

    .container {
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(10px);
      border-radius: 20px;
      padding: 30px;
      width: 100%;
      max-width: 500px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.4);
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
      font-size: 1.8rem;
      color: #38bdf8;
    }

    label {
      font-weight: 500;
      display: block;
      margin-top: 15px;
      color: #e2e8f0;
    }

    select, textarea, input[type="submit"] {
      width: 100%;
      padding: 12px;
      margin-top: 10px;
      border-radius: 10px;
      border: none;
      font-size: 1em;
    }

    select, textarea {
      background-color: rgba(255,255,255,0.1);
      color: #fff;
    }

    select option {
      color: #000;
    }

    textarea::placeholder {
      color: #ccc;
    }

    input[type="submit"] {
      background: linear-gradient(to right, #22c55e, #16a34a);
      color: white;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
      margin-top: 25px;
    }

    input[type="submit"]:hover {
      background: linear-gradient(to right, #16a34a, #15803d);
    }

    .back {
      text-align: center;
      margin-top: 20px;
    }

    .back a {
      color: #38bdf8;
      text-decoration: none;
      font-weight: 500;
    }

    .back a:hover {
      text-decoration: underline;
    }

    @media (max-width: 500px) {
      .container {
        padding: 25px 20px;
      }

      h2 {
        font-size: 1.5rem;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>🛠️ Request Maintenance</h2>
    <form method="post">
      <label for="asset_id">Select Asset</label>
      <select name="asset_id" required>
        <option value="">-- Choose an Asset --</option>
        <?php while ($row = $assets->fetch_assoc()) { ?>
          <option value="<?= $row['asset_id']; ?>"><?= htmlspecialchars($row['asset_name']); ?></option>
        <?php } ?>
      </select>

      <label for="issue_description">Issue Description</label>
      <textarea name="issue_description" rows="4" placeholder="Describe the issue..." required></textarea>

      <input type="submit" value="Submit Request">
    </form>

    <div class="back">
      <a href="user_dashboard.php">⬅ Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
