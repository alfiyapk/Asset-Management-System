<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// ✅ Handle delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    if ($id == $_SESSION['user_id']) {
        echo "<script>alert('⚠️ You cannot delete your own admin account.');</script>";
    } else {
      // ✅ Step 1: Get all asset IDs assigned to the user
$getAssets = $conn->prepare("SELECT asset_id FROM assigned_assets WHERE user_id = ?");
$getAssets->bind_param("i", $id);
$getAssets->execute();
$resultAssets = $getAssets->get_result();

// ✅ Step 2: Set asset status to 'Available'
while ($row = $resultAssets->fetch_assoc()) {
    $assetId = $row['asset_id'];
    $updateAsset = $conn->prepare("UPDATE assets SET asset_status = 'available' WHERE asset_id = ?");
    $updateAsset->bind_param("i", $assetId);
    $updateAsset->execute();
}

// ✅ Step 3: Delete assignment records
$deleteAssignments = $conn->prepare("DELETE FROM assigned_assets WHERE user_id = ?");
$deleteAssignments->bind_param("i", $id);
$deleteAssignments->execute();

// ✅ Step 4: Delete user (only if not an admin)
$deleteUser = $conn->prepare("DELETE FROM users WHERE user_id = ? AND role != 'admin'");
$deleteUser->bind_param("i", $id);
if ($deleteUser->execute()) {
    echo "<script>alert('✅ User and their assigned assets updated successfully.'); window.location='view_users.php';</script>";
    exit();
} else {
    echo "<script>alert('❌ Failed to delete user.');</script>";
}

    }
}

// ✅ Fetch users
$sql = "SELECT * FROM users ORDER BY role DESC, name ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registered Users - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      margin: 0;
      padding: 30px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      min-height: 100vh;
    }
    .container {
      width: 100%;
      max-width: 1100px;
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5);
    }
    h2 {
      text-align: center;
      color: #38bdf8;
      margin-bottom: 30px;
      font-size: 2rem;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      overflow: hidden;
      border-radius: 12px;
    }
    thead {
      background: #2563eb;
    }
    th, td {
      padding: 14px;
      text-align: center;
      font-size: 0.95rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    th {
      color: #fff;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    tr:hover {
      background-color: rgba(255, 255, 255, 0.04);
      transition: background 0.3s ease;
    }
    .badge {
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 500;
      color: #fff;
      display: inline-block;
    }
    .role-admin {
      background-color: #ef4444;
    }
    .role-user {
      background-color: #22c55e;
    }
    .delete-btn {
  display: inline-block;
  background-color: #dc2626;
  color: #fff;
  padding: 6px 14px;
  border-radius: 8px;
  font-weight: 600;
  text-decoration: none;
  transition: background-color 0.3s ease;
}

.delete-btn:hover {
  background-color: #b91c1c;
}

    .back {
      text-align: center;
      margin-top: 25px;
    }
    .back a {
      display: inline-block;
      padding: 10px 20px;
      background: linear-gradient(to right, #3b82f6, #1e40af);
      color: #fff;
      border-radius: 10px;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s ease;
    }
    .back a:hover {
      background: linear-gradient(to right, #1e40af, #1e3a8a);
    }
    @media (max-width: 768px) {
      th, td {
        padding: 10px;
        font-size: 0.85rem;
      }
      .container {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>👥 All Registered Users</h2>

    <table>
      <thead>
        <tr>
          <th>User ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
          <tr>
            <td><?= $row['user_id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
            <td>
              <span class="badge role-<?= $row['role']; ?>">
                <?= ucfirst($row['role']); ?>
              </span>
            </td>
            <td>
              <?php if ($row['role'] !== 'admin') { ?>
                <a href="?delete=<?= $row['user_id']; ?>" 
   class="delete-btn" 
   onclick="return confirm('Are you sure you want to delete this user?');">
   <i class="fas fa-trash"></i> Delete
</a>
              <?php } else {
                echo "-";
              } ?>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>

    <div class="back">
      <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
  </div>
</body>
</html>