
<?php
$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Reset Password - Asset Management</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: #0e1a2b;
      color: #fff;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .reset-container {
      background: rgba(255, 255, 255, 0.05);
      padding: 40px 30px;
      border-radius: 16px;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .reset-container h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #00d4ff;
    }

    .reset-container input {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border: none;
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.1);
      color: #fff;
      font-size: 14px;
    }

    .reset-container input:focus {
      outline: none;
      background: rgba(255, 255, 255, 0.2);
      box-shadow: 0 0 0 2px #00d4ff;
    }

    .reset-container button {
      width: 100%;
      padding: 12px;
      background-color: #ff814c;
      color: white;
      font-weight: 600;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .reset-container button:hover {
      background-color: #ff5c1a;
    }

    .footer-text {
      margin-top: 20px;
      text-align: center;
      font-size: 14px;
      color: #aaa;
    }

    .footer-text a {
      color: #00d4ff;
      text-decoration: none;
    }

    .footer-text a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="reset-container">
    <form action="update_password.php" method="POST">
      <h2>Reset Password</h2>
      <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">

      <input type="password" name="new_password" placeholder="New Password" required />
      <input type="password" name="confirm_password" placeholder="Confirm Password" required />
      <button type="submit">Reset Password</button>

      <div class="footer-text">
        Back to <a href="login.html">Login</a>
      </div>
    </form>
  </div>
</body>
</html>
