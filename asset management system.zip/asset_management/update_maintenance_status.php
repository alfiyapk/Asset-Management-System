<?php
session_start();
include 'db.php';

// Only admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle status update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_id'], $_POST['status'])) {
    $id = $_POST['request_id'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE maintenance_requests SET status=? WHERE request_id=?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    header("Location: update_maintenance_status.php");
    exit();
}

// Fetch all maintenance requests
$sql = "SELECT m.*, u.name FROM maintenance_requests m 
        JOIN users u ON m.user_id = u.user_id 
        ORDER BY m.request_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Maintenance Requests</title>
    <style>
        body {
            background: url('assets/asset.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: white;
            margin-bottom: 20px;
        }

        table {
            width: 95%;
            margin: auto;
            background: rgba(255,255,255,0.95);
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #007bff;
            color: white;
        }

        form select {
            padding: 6px;
            border-radius: 6px;
        }

        form input[type="submit"] {
            background: #28a745;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            cursor: pointer;
        }

        form input[type="submit"]:hover {
            background: #218838;
        }

        .back {
            text-align: center;
            margin-top: 20px;
        }

        .back a {
            color: white;
            font-weight: bold;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>All Maintenance Requests</h2>
    <table>
        <tr>
            <th>Request ID</th>
            <th>User</th>
            <th>Asset</th>
            <th>Issue Description</th>
            <th>Status</th>
            <th>Update</th>
            <th>Requested On</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['request_id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['asset_name']); ?></td>
            <td><?= htmlspecialchars($row['issue_description']); ?></td>
            <td><strong><?= $row['status']; ?></strong></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="request_id" value="<?= $row['request_id']; ?>">
                    <select name="status">
                        <option value="Pending" <?= $row['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="In Progress" <?= $row['status'] == 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                        <option value="Completed" <?= $row['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
                    </select>
                    <input type="submit" value="Update">
                </form>
            </td>
            <td><?= $row['request_date']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <div class="back">
        <a href="admin_dashboard.php">⬅ Back to Dashboard</a>
    </div>
</body>
</html>

