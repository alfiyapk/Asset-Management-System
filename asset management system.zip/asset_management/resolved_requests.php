<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db.php';

// ✅ User access check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// ✅ Fetch resolved maintenance requests
$sql = "SELECT m.request_id, m.issue_description, m.status, a.asset_name 
        FROM maintenance_requests m
        JOIN assets a ON m.asset_id = a.asset_id
        WHERE m.user_id = ? AND m.status = 'completed'";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Resolved Requests</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      padding: 40px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
      min-height: 100vh;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    h2 {
      text-align: center;
      font-size: 1.8em;
      color: #22c55e;
      margin-bottom: 25px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 20px;
    }

    th, td {
      padding: 14px 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      text-align: center;
    }

    th {
      background-color: #16a34a;
      color: white;
      font-weight: 600;
      text-transform: uppercase;
    }

    td {
      color: #e2e8f0;
    }

    tr:hover {
      background-color: rgba(255, 255, 255, 0.05);
    }

    .badge {
      display: inline-block;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 0.85em;
      font-weight: 600;
    }

    .badge-success {
      background-color: #22c55e;
      color: #fff;
    }

    .muted {
      color: #9ca3af;
      font-style: italic;
    }

    .back {
      text-align: center;
      margin-top: 30px;
    }

    .back a {
      background:#2563eb;
      color:#fff;
      padding:10px 16px;
      border-radius:8px;
      text-decoration:none;
      font-weight:600;
      transition:0.3s;
    }

    .back a:hover {
      background:#38bdf8;
      color:#0f172a;
    }

    @media (max-width: 768px) {
      table, th, td {
        font-size: 0.9em;
      }

      .container {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>✅ Resolved Maintenance Requests</h2>

    <table>
      <thead>
        <tr>
          <th>Request ID</th>
          <th>Asset</th>
          <th>Issue</th>
          <th>Status</th>
        
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['request_id']) ?></td>
              <td><?= htmlspecialchars($row['asset_name']) ?></td>
              <td><?= htmlspecialchars($row['issue_description']) ?></td>
              <td><span class="badge badge-success"><?= htmlspecialchars($row['status']) ?></span></td>
            
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" class="muted">No resolved requests found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="back">
    <a href="user_dashboard.php">⬅ Back to Dashboard</a>
  </div>
</body>
</html>
