<?php
session_start();
require 'db.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// ✅ Admin Access Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// ✅ Handle Return Request
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['assign_id'])) {
    $assign_id = intval($_POST['assign_id']);

    $sql = "SELECT aa.*, u.email, u.name AS user_name, a.asset_name 
            FROM assigned_assets aa
            JOIN users u ON aa.user_id = u.user_id
            JOIN assets a ON aa.asset_id = a.asset_id
            WHERE aa.assign_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $assign_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $assetInfo = $result->fetch_assoc();

    if ($assetInfo) {
        $user_email = $assetInfo['email'];
        $user_id = $assetInfo['user_id'];
        $asset_name = $assetInfo['asset_name'];
        $user_name = $assetInfo['user_name'];

        // ✅ Send Email Notification
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'alfiyapk84@gmail.com';
            $mail->Password = 'hlctmiskntvvixhf'; // App password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('alfiyapk84@gmail.com', 'Admin - Asset Management');
            $mail->addAddress($user_email, $user_name);
            $mail->isHTML(true);
            $mail->Subject = 'Asset Return Request';
            $mail->Body = "Dear $user_name,<br><br>
                You are requested to return the assigned asset: <strong>$asset_name</strong>.<br>
                Kindly return it at your earliest convenience.<br><br>
                Regards,<br>Asset Management System";

            $mail->send();
        } catch (Exception $e) {
            error_log("Email failed: {$mail->ErrorInfo}");
        }

        // ✅ Add Notification to DB
        $message = "Admin requested return of asset: <strong>$asset_name</strong>.";
        $notif_sql = "INSERT INTO notifications (user_id, message, created_at) VALUES (?, ?, NOW())";
        $notif_stmt = $conn->prepare($notif_sql);
        $notif_stmt->bind_param("is", $user_id, $message);
        $notif_stmt->execute();

        // ✅ Mark asset as requested
        $update_sql = "UPDATE assigned_assets SET return_status = 'requested' WHERE assign_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $assign_id);
        $update_stmt->execute();

        header("Location: request_return.php?success=1");
        exit();
    } else {
        header("Location: request_return.php?error=1");
        exit();
    }
}

// ✅ Fetch All Assigned Assets
$query = "SELECT aa.assign_id, u.user_id, u.name AS user_name, a.asset_id, a.asset_name, aa.return_status 
          FROM assigned_assets aa
          JOIN users u ON aa.user_id = u.user_id
          JOIN assets a ON aa.asset_id = a.asset_id";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Request Return - Admin Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 40px;
      background: linear-gradient(to right, #0f172a, #1e293b);
      color: #f1f5f9;
    }
    .container {
      max-width: 1100px;
      margin: auto;
      background: rgba(255,255,255,0.04);
      padding: 30px;
      border-radius: 16px;
      backdrop-filter: blur(12px);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }
    h2 {
      text-align: center;
      color: #38bdf8;
      margin-bottom: 30px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255,255,255,0.02);
      border-radius: 10px;
      overflow: hidden;
    }
    th, td {
      padding: 14px;
      text-align: center;
      border-bottom: 1px solid #334155;
    }
    th {
      background: #1e293b;
      color: #f1f5f9;
      font-weight: 600;
    }
    tr:hover {
      background-color: rgba(148, 163, 184, 0.1);
    }
    .btn {
      background: #f97316;
      border: none;
      color: #fff;
      padding: 8px 14px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: background 0.3s ease;
    }
    .btn:hover {
      background: #fb923c;
    }
    .btn.disabled {
      background: #64748b;
      cursor: not-allowed;
      color: #f1f5f9;
      font-style: italic;
    }
  </style>
  <script>
  function disableButton(form) {
      const btn = form.querySelector('button');
      btn.disabled = true;
      btn.classList.add('disabled');
      btn.textContent = 'Requested';
      return true; // allow form submission
  }
  </script>
</head>
<body>

<div class="container">
  <h2>📦 Request Return of Assigned Assets</h2>

  <?php if (isset($_GET['success'])): ?>
    <script>alert('✅ Return request successfully sent to the user!');</script>
  <?php elseif (isset($_GET['error'])): ?>
    <script>alert('❌ Error: Could not process the request.');</script>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <th>Assign ID</th>
        <th>User Name</th>
        <th>User ID</th>
        <th>Asset Name</th>
        <th>Asset ID</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['assign_id'] ?></td>
          <td><?= htmlspecialchars($row['user_name']) ?></td>
          <td><?= $row['user_id'] ?></td>
          <td><?= htmlspecialchars($row['asset_name']) ?></td>
          <td><?= $row['asset_id'] ?></td>
          <td>
            <?php if ($row['return_status'] === 'requested'): ?>
              <span style="color:orange;font-weight:bold;">Requested</span>
            <?php elseif ($row['return_status'] === 'returned'): ?>
              <span style="color:green;font-weight:bold;">Returned</span>
            <?php else: ?>
              <span style="color:gray;">Pending</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($row['return_status'] === 'requested'): ?>
              <button class="btn disabled" disabled>Requested</button>
            <?php elseif ($row['return_status'] === 'returned'): ?>
              <button class="btn disabled" disabled>Returned</button>
            <?php else: ?>
              <form method="POST" action="" onsubmit="return disableButton(this)">
                <input type="hidden" name="assign_id" value="<?= $row['assign_id'] ?>">
                <button type="submit" class="btn">Request Return</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <div style="text-align:center; margin:30px 0;">
    <a href="admin_dashboard.php" class="btn">⬅ Back to Dashboard</a>
  </div>
</div>

</body>
</html>
