
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

session_start();
include 'db.php';

// Allow only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Validate asset_id
if (empty($_GET['asset_id'])) {
    header("Location: view_assets.php?msg=invalid");
    exit();
}

$asset_id = intval($_GET['asset_id']);
$admin_id = intval($_SESSION['user_id']);

try {

    // STEP 1: Check asset status
    $checkStatus = $conn->prepare("SELECT asset_status FROM assets WHERE asset_id = ?");
    $checkStatus->bind_param("i", $asset_id);
    $checkStatus->execute();
    $asset = $checkStatus->get_result()->fetch_assoc();
    $checkStatus->close();

    if (!$asset) {
        header("Location: view_assets.php?msg=notfound");
        exit();
    }

    // Block deletion if asset is NOT available
    if ($asset['asset_status'] !== 'available') {
        echo "<script>
                alert('❌ Unable to delete this asset. Update the status to AVAILABLE before deleting.');
                window.location.href='view_assets.php';
              </script>";
        exit();
    }

    // BEGIN TRANSACTION
    $conn->begin_transaction();

    // STEP 2: Delete all references to this asset in ALL child tables
    $dbRow = $conn->query("SELECT DATABASE()")->fetch_row();
    $dbName = $dbRow[0] ?? '';

    // Find FK references to assets
    $fkStmt = $conn->prepare("
        SELECT TABLE_NAME, COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE REFERENCED_TABLE_NAME = 'assets'
          AND REFERENCED_TABLE_SCHEMA = ?
    ");
    $fkStmt->bind_param("s", $dbName);
    $fkStmt->execute();
    $fkRes = $fkStmt->get_result();

    // For every table using asset_id as FK → DELETE rows fully
    while ($fkRow = $fkRes->fetch_assoc()) {

        $table = $fkRow['TABLE_NAME'];
        $column = $fkRow['COLUMN_NAME'];

        // Extra safety
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
            continue;
        }

        // Full delete from child table
        $deleteChild = $conn->prepare("DELETE FROM `$table` WHERE `$column` = ?");
        $deleteChild->bind_param("i", $asset_id);
        $deleteChild->execute();
        $deleteChild->close();
    }
    $fkStmt->close();

    // STEP 3: Delete from asset_history if exists
    if ($conn->query("SHOW TABLES LIKE 'asset_history'")->num_rows > 0) {
        $delHistory = $conn->prepare("DELETE FROM asset_history WHERE asset_id = ?");
        $delHistory->bind_param("i", $asset_id);
        $delHistory->execute();
        $delHistory->close();
    }

    // STEP 4: Log deletion
    $conn->query("
        CREATE TABLE IF NOT EXISTS asset_deletion_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            asset_id INT,
            admin_id INT,
            note TEXT,
            deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $note = "Full asset deletion by Admin (User ID: {$admin_id})";
    $log = $conn->prepare("INSERT INTO asset_deletion_log (asset_id, admin_id, note) VALUES (?, ?, ?)");
    $log->bind_param("iis", $asset_id, $admin_id, $note);
    $log->execute();
    $log->close();

    // STEP 5: Delete the asset from assets table
    $delAsset = $conn->prepare("DELETE FROM assets WHERE asset_id = ?");
    $delAsset->bind_param("i", $asset_id);
    $delAsset->execute();
    $delAsset->close();

    // Commit
    $conn->commit();

    header("Location: view_assets.php?msg=deleted");
    exit();

} catch (Exception $e) {
    if ($conn->in_transaction) $conn->rollback();
    $msg = urlencode($e->getMessage());
    header("Location: view_assets.php?msg=error&err={$msg}");
    exit();
}
?>
