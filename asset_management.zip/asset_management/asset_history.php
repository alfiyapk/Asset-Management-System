
<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Asset History Report | Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    body {
      margin: 0;
      padding: 40px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      font-family: 'Poppins', sans-serif;
      color: #fff;
    }

    .container {
      max-width: 1100px;
      margin: auto;
      background: rgba(255,255,255,0.05);
      padding: 25px;
      border-radius: 16px;
      backdrop-filter: blur(10px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
    }

    h2 {
      text-align: center;
      color: #38bdf8;
      margin-bottom: 30px;
      font-size: 26px;
    }

    .toolbar {
      display: flex;
      justify-content: space-between;
      margin-bottom: 15px;
      flex-wrap: wrap;
      gap: 10px;
    }

    .toolbar input {
      padding: 10px 15px;
      border-radius: 8px;
      border: none;
      font-size: 14px;
      width: 260px;
    }

    .export-btn {
      padding: 10px 16px;
      border-radius: 8px;
      border: none;
      font-weight: 600;
      cursor: pointer;
      margin-left: 6px;
    }

    .excel-btn { background: #10b981; color: #fff; }
    .pdf-btn { background: #9333ea; color: #fff; }

    table {
      width: 100%;
      border-collapse: collapse;
      border-radius: 12px;
      overflow: hidden;
      background: rgba(255,255,255,0.05);
    }

    th, td {
      padding: 12px 15px;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    th {
      background: #2563eb;
      color: #fff;
      text-transform: uppercase;
    }

    td { color: #e2e8f0; }

    .badge {
      padding: 6px 12px;
      border-radius: 6px;
      font-weight: bold;
      font-size: 0.85rem;
    }

    .assigned { background: #0ea5e9; color: #fff; }
    .returned { background: #22c55e; color: #fff; }

    a.back-btn {
      display: block;
      width: 250px;
      margin: 40px auto;
      text-align: center;
      background: #2563eb;
      padding: 10px 16px;
      color: #fff;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 600;
      transition: .3s;
    }

    a.back-btn:hover {
      background: #1e40af;
    }
  </style>
</head>
<body>

<div class="container">

<h2>📜 Asset Assignment & Return History</h2>

<!-- Search + Export Buttons -->
<div class="toolbar">
    <input type="text" id="searchInput" placeholder="Search user, asset, status..." onkeyup="applySearch()">

    <div>
      <button class="export-btn excel-btn" onclick="exportToExcel()">📥 Export Excel</button>
      <button class="export-btn pdf-btn" onclick="exportToPDF()">📄 Export PDF</button>
    </div>
</div>

<table id="historyTable">
  <thead>
    <tr>
      <th>User ID</th>
      <th>User Name</th>
      <th>Asset ID</th>
      <th>Asset Name</th>
      <th>Assigned Date</th>
      <th>Returned Date</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <?php
    // Assigned assets
    $sql1 = "SELECT aa.user_id, u.name AS user_name, a.asset_id, a.asset_name, aa.assigned_date
             FROM assigned_assets aa
             JOIN users u ON aa.user_id = u.user_id
             JOIN assets a ON aa.asset_id = a.asset_id";
    $res1 = $conn->query($sql1);

    while ($row = $res1->fetch_assoc()) {
        echo "<tr>
                <td>{$row['user_id']}</td>
                <td>" . htmlspecialchars($row['user_name']) . "</td>
                <td>{$row['asset_id']}</td>
                <td>" . htmlspecialchars($row['asset_name']) . "</td>
                <td>" . date('d M Y', strtotime($row['assigned_date'])) . "</td>
                <td>-</td>
                <td><span class='badge assigned'>Assigned</span></td>
              </tr>";
    }

    // Returned assets
    $sql2 = "SELECT ra.user_id, u.name AS user_name, a.asset_id, a.asset_name, ra.assigned_at, ra.returned_at
             FROM returned_assets ra
             JOIN users u ON ra.user_id = u.user_id
             JOIN assets a ON ra.asset_id = a.asset_id";

    $res2 = $conn->query($sql2);

    while ($row = $res2->fetch_assoc()) {
        echo "<tr>
                <td>{$row['user_id']}</td>
                <td>" . htmlspecialchars($row['user_name']) . "</td>
                <td>{$row['asset_id']}</td>
                <td>" . htmlspecialchars($row['asset_name']) . "</td>
                <td>" . date('d M Y', strtotime($row['assigned_at'])) . "</td>
                <td>" . date('d M Y', strtotime($row['returned_at'])) . "</td>
                <td><span class='badge returned'>Returned</span></td>
              </tr>";
    }
    ?>
  </tbody>
</table>

<a href="admin_dashboard.php" class="back-btn">⬅ Back to Dashboard</a>

</div>

<!-- SheetJS -->
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<!-- jsPDF -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>

<script>
// SEARCH FILTER
function applySearch() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll("#historyTable tbody tr");

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        row.style.display = text.includes(input) ? "" : "none";
    });
}

// EXCEL EXPORT
function exportToExcel() {
    const table = document.getElementById("historyTable");
    const wb = XLSX.utils.table_to_book(table, { sheet: "History Report" });
    XLSX.writeFile(wb, "asset_history_report.xlsx");
}

// PDF EXPORT
async function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF("p", "pt", "a4");

    const primary = [37, 99, 235];
    const secondary = [56, 189, 248];
    const pageWidth = doc.internal.pageSize.getWidth();

    // HEADER
    doc.setFillColor(...primary);
    doc.rect(0, 0, pageWidth, 80, "F");

    const logo = "data:image/png;base64,<?= base64_encode(file_get_contents('companylogo.png')); ?>";
    doc.addImage(logo, "PNG", 60, 10, 110, 60);

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.text("SafeCare Technologies Pvt. Ltd.", 200, 35);

    doc.setFontSize(10);
    doc.text("Kacheripady, Muvattupuzha, Kerala 686673", 200, 50);
    doc.text("Email: info@www.safecaretec.in | Phone: +91 098471 84455", 200, 65);

    // Title
    doc.setTextColor(...secondary);
    doc.setFontSize(16);
    const title = "Asset Assignment & Return History";
    doc.text(title, (pageWidth - doc.getTextWidth(title)) / 2, 110);

    doc.autoTable({
        html: "#historyTable",
        startY: 140,
        theme: "striped",
        styles: { halign: "center", fontSize: 9, cellPadding: 5 },
        headStyles: { fillColor: primary, textColor: 255 },
        alternateRowStyles: { fillColor: [240, 248, 255] },
        margin: { left: 40, right: 40 }
    });

    // Footer
    const pages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pages; i++) {
        doc.setPage(i);
        doc.setFontSize(9);
        doc.setTextColor(120);
        doc.text(`Page ${i} of ${pages}`, pageWidth - 70, doc.internal.pageSize.height - 20);
        doc.text("SafeCare Technologies • Reliable Asset & Maintenance Management", 40, doc.internal.pageSize.height - 20);
    }

    doc.save("asset_history_report.pdf");
}
</script>

</body>
</html>