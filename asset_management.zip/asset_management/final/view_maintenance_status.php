<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT mr.*, a.asset_name 
        FROM maintenance_requests mr 
        JOIN assets a ON mr.asset_id = a.asset_id 
        WHERE mr.user_id = ? 
        ORDER BY mr.request_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Maintenance Status</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      margin: 0;
      padding: 40px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(10px);
      border-radius: 16px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    h2 {
      text-align: center;
      font-size: 1.8em;
      color: #38bdf8;
      margin-bottom: 25px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255, 255, 255, 0.03);
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 20px;
    }

    th, td {
      padding: 14px 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      text-align: center;
    }

    th {
      background-color: #2563eb;
      color: white;
      font-weight: 600;
      text-transform: uppercase;
    }

    td {
      color: #e2e8f0;
    }

    tr:hover {
      background-color: rgba(255, 255, 255, 0.05);
    }

    .status-pending {
      color: #fbbf24;
      font-weight: 600;
    }

    .status-in_progress {
      color: #60a5fa;
      font-weight: 600;
    }

    .status-completed,
    .status-resolved {
      color: #22c55e;
      font-weight: 600;
    }

    .back {
      text-align: center;
    }

    .back a {
      color: #38bdf8;
      text-decoration: none;
      font-weight: 500;
    }

    .back a:hover {
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      table, th, td {
        font-size: 0.9em;
      }

      .container {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>🛠️ Your Maintenance Requests</h2>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Asset</th>
          <th>Description</th>
          <th>Status</th>
          <th>Requested On</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
          <tr>
            <td><?= $row['request_id']; ?></td>
            <td><?= htmlspecialchars($row['asset_name']); ?></td>
            <td><?= htmlspecialchars($row['issue_description']); ?></td>
            <td class="status-<?= strtolower(str_replace(' ', '', $row['status'])); ?>">
              <?= htmlspecialchars(ucfirst($row['status'])); ?>
            </td>
            <td><?= date("d M Y, h:i A", strtotime($row['request_date'])); ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
<div style="margin-top:40px; text-align:center;">
    <a href="user_dashboard.php" 
       style="background:#2563eb; color:#fff; padding:10px 16px; border-radius:8px; 
              text-decoration:none; font-weight:600; transition:0.3s;">
      ⬅ Back to Dashboard
    </a>
  </div>
  </div>
</body>
</html>
