<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Logout - Asset Management System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="refresh" content="5;url=login.html" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
    }

    .logout-box {
      background: rgba(255, 255, 255, 0.05);
      padding: 40px 30px;
      border-radius: 20px;
      backdrop-filter: blur(12px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5);
      width: 90%;
      max-width: 500px;
    }

    .logout-box h1 {
      font-size: 2.5em;
      color: #38bdf8;
      margin-bottom: 15px;
    }

    .logout-box p {
      font-size: 1.1em;
      color: #f1f1f1;
      margin-bottom: 10px;
    }

    .logout-box small {
      display: block;
      margin-top: 20px;
      font-style: italic;
      color: #bbbbbb;
    }

    .logout-box a.button {
      display: inline-block;
      margin-top: 25px;
      padding: 12px 25px;
      background: linear-gradient(to right, #22d3ee, #3b82f6);
      color: #fff;
      font-weight: 600;
      text-decoration: none;
      border-radius: 10px;
      transition: background 0.3s ease;
    }

    .logout-box a.button:hover {
      background: linear-gradient(to right, #0ea5e9, #2563eb);
    }

    @media (max-width: 500px) {
      .logout-box {
        padding: 30px 20px;
      }

      .logout-box h1 {
        font-size: 2em;
      }

      .logout-box p {
        font-size: 1em;
      }
    }
  </style>
</head>
<body>
  <div class="logout-box">
    <h1>Thank You!</h1>
    <p>You have been successfully logged out.</p>
    <p>We hope that you had a smooth and secure experience.</p>
    <a href="login.html" class="button">🔐 Login Again</a>
    <small>You will be redirected automatically in 5 seconds...</small>
  </div>
</body>
</html>
