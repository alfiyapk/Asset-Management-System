<?php
session_start();
include 'db.php';

// Only logged-in users allowed
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Asset Requests</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      padding: 40px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      font-family: 'Poppins', sans-serif;
      color: #fff;
    }

    h2 {
      text-align: center;
      color: #38bdf8;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255,255,255,0.05);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
    }

    th, td {
      padding: 12px 15px;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    th {
      background: rgba(255,255,255,0.1);
      color: #f8fafc;
    }

    td {
      color: #e2e8f0;
    }

    .status {
      padding: 5px 10px;
      border-radius: 8px;
      font-weight: bold;
    }

    .Pending {
      background-color: #f59e0b;
      color: white;
    }

    .Approved {
      background-color: #22c55e;
      color: white;
    }

    .Rejected {
      background-color: #ef4444;
      color: white;
    }

    .back {
      text-align: center;
      margin-top: 20px;
    }

    .back a {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 500;
    }

    .back a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <h2>📋 My Asset Requests</h2>

  <table>
    <thead>
      <tr>
        <th>Asset Name</th>
        <th>Description</th>
        <th>Requested Date</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $stmt = $conn->prepare("SELECT asset_name, description, request_date, status 
                              FROM asset_requests 
                              WHERE user_id = ? 
                              ORDER BY request_date DESC");
      $stmt->bind_param("i", $user_id);
      $stmt->execute();
      $result = $stmt->get_result();

      while ($row = $result->fetch_assoc()) {
          echo "<tr>
                  <td>" . htmlspecialchars($row['asset_name']) . "</td>
                  <td>" . htmlspecialchars($row['description']) . "</td>
                  <td>" . date("d M Y h:i A", strtotime($row['request_date'])) . "</td>
                  <td><span class='status {$row['status']}'>" . $row['status'] . "</span></td>
                </tr>";
      }
      ?>
    </tbody>
  </table>

  <div class="back">
    <a href="user_dashboard.php">⬅ Back to Dashboard</a>
  </div>
</body>
</html>
