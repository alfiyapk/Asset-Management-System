                                            
<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

$query = "SELECT a.asset_id, a.asset_name, a.asset_type, a.asset_status, 
          u.name AS assigned_to
          FROM assets a
          LEFT JOIN assigned_assets aa ON a.asset_id = aa.asset_id
          LEFT JOIN users u ON aa.user_id = u.user_id
          ORDER BY a.asset_name";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Asset Tracking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
 
<style>
  * {
    box-sizing: border-box;
    font-family: 'Inter', sans-serif;
  }

  body {
    margin: 0;
    padding: 30px 20px;
    background: linear-gradient(to bottom right, #0f172a, #1e293b);
    color: #fff;
  }

  .container {
    max-width: 1100px;
    margin: auto;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 16px;
    padding: 30px;
    backdrop-filter: blur(10px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.4);
  }

  h2 {
    text-align: center;
    color: #38bdf8;
    font-size: 2rem;
    margin-bottom: 30px;
  }

  .filters {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-bottom: 20px;
    gap: 15px;
  }

  .filters input,
  .filters select {
    flex: 1;
    min-width: 240px;
    padding: 12px 16px;
    border: none;
    border-radius: 12px;
    background: linear-gradient(to right, rgb(245, 241, 241), rgba(255, 255, 255, 0.06));
    color: black;
    backdrop-filter: blur(8px);
    font-size: 1em;
    font-weight: 500;
    transition: border 0.3s, box-shadow 0.3s;
    box-shadow: inset 0 0 0 1px rgb(245, 242, 242);
  }

  .filters input::placeholder {
    color:rgb(11, 11, 11);
  }

  .filters input:focus,
  .filters select:focus {
    outline: none;
    box-shadow: 0 0 0 2px #38bdf8;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }

  th, td {
    padding: 14px 16px;
    text-align: center;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  }

  th {
    background-color: #2563eb;
    color: #fff;
    font-weight: 600;
    text-transform: uppercase;
  }

  tr:hover {
    background-color: 8rgba(255, 255, 255, 0.03);
  }

  .badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.85em;
    font-weight: 600;
    display: inline-block;
  }

  .available {
    background: #22c55e;
    color: white;
  }

  .allocated {
    background: #3b82f6;
    color: white;
  }

  .under_maintenance {
    background: #f59e0b;
    color: #1f2937;
  }

  .back {
    margin-top: 30px;
    text-align: center;
  }

  .back a {
    display: inline-block;
    padding: 12px 20px;
    background: linear-gradient(to right, #3b82f6, #1e40af);
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 600;
    transition: background 0.3s ease;
  }

  .back a:hover {
    background: linear-gradient(to right, #1e40af, #1e3a8a);
  }

  @media (max-width: 768px) {
    .filters {
      flex-direction: column;
    }

    table {
      font-size: 0.9em;
    }

    th, td {
      padding: 10px;
    }
  }
</style>
<div class="container">
        <h2>📍 Asset Tracking</h2>
<!-- Filter Section -->
<div class="filters">
  <input type="text" id="searchInput" placeholder="🔍 Search by asset name, type, or user...">
  <select id="statusFilter">
    <option value="">🔄 All Statuses</option>
    <option value="Available">✅ Available</option>
    <option value="Allocated">📦 Allocated</option>
    <option value="under_maintenance">🛠️ Under Maintenance</option>
  </select>
</div>

    <table id="assetTable">
      <thead>
        <tr>
          <th>Asset Name</th>
          <th>Type</th>
          <th>Status</th>
          <th>Assigned To</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) {
          $statusClass = str_replace(' ', '_', $row['asset_status']);
        ?>
          <tr>
            <td><?= htmlspecialchars($row['asset_name']); ?></td>
            <td><?= htmlspecialchars($row['asset_type']); ?></td>
            <td><span class="badge <?= $statusClass ?>"><?= $row['asset_status']; ?></span></td>
            <td><?= $row['assigned_to'] ?? '<em>Not Assigned</em>'; ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>

    <div class="back">
      <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
  </div>

  <script>
    const searchInput = document.getElementById("searchInput");
    const statusFilter = document.getElementById("statusFilter");
    const tableBody = document.querySelector("#assetTable tbody");

    function filterTable() {
      const search = searchInput.value.toLowerCase();
      const status = statusFilter.value.toLowerCase();

      for (let row of tableBody.rows) {
        const [nameCell, typeCell, statusCell, userCell] = row.cells;
        const matchSearch = (
          nameCell.textContent.toLowerCase().includes(search) ||
          typeCell.textContent.toLowerCase().includes(search) ||
          userCell.textContent.toLowerCase().includes(search)
        );
        const matchStatus = !status || statusCell.textContent.toLowerCase() === status;

        row.style.display = matchSearch && matchStatus ? "" : "none";
      }
    }

    searchInput.addEventListener("keyup", filterTable);
    statusFilter.addEventListener("change", filterTable);
  </script>
</body>
</html>
