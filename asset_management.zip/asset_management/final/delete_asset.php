
<?php
// Debug mode (recommended only for development)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

session_start();
include 'db.php';

// ✅ Allow only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// ✅ Validate asset_id
if (empty($_GET['asset_id'])) {
    header("Location: view_assets.php?msg=invalid");
    exit();
}

$asset_id = intval($_GET['asset_id']);
$admin_id = intval($_SESSION['user_id']);

try {
    $conn->begin_transaction();

    // ✅ 1) Check if asset exists
    $chk = $conn->prepare("SELECT asset_id FROM assets WHERE asset_id = ?");
    $chk->bind_param("i", $asset_id);
    $chk->execute();
    $res = $chk->get_result();
    if ($res->num_rows === 0) {
        $chk->close();
        $conn->rollback();
        header("Location: view_assets.php?msg=notfound");
        exit();
    }
    $chk->close();

    // ✅ 2) Create log table (if not exists)
    $conn->query("
        CREATE TABLE IF NOT EXISTS asset_deletion_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            asset_id INT NOT NULL,
            admin_id INT NULL,
            note TEXT,
            deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // ✅ 3) Insert deletion log
    $note = "Asset deleted by Admin (User ID: {$admin_id})";
    $ins = $conn->prepare("INSERT INTO asset_deletion_log (asset_id, admin_id, note) VALUES (?, ?, ?)");
    $ins->bind_param("iis", $asset_id, $admin_id, $note);
    $ins->execute();
    $ins->close();

    // ✅ 4) Handle FK references safely — set to NULL (instead of deleting child rows)
    $dbRow = $conn->query("SELECT DATABASE()")->fetch_row();
    $dbName = $dbRow[0] ?? '';

    $fkStmt = $conn->prepare("
        SELECT TABLE_NAME, COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE REFERENCED_TABLE_NAME = 'assets'
          AND REFERENCED_TABLE_SCHEMA = ?
    ");
    $fkStmt->bind_param("s", $dbName);
    $fkStmt->execute();
    $fkRes = $fkStmt->get_result();

    while ($fkRow = $fkRes->fetch_assoc()) {
        $table = $fkRow['TABLE_NAME'];
        $column = $fkRow['COLUMN_NAME'];

        // Prevent SQL injection through metadata
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
            continue; // skip unsafe identifiers
        }

        // ✅ Update dependent rows to NULL instead of deleting them
        $updateSql = "UPDATE `{$table}` SET `{$column}` = NULL WHERE `{$column}` = ?";
        $updStmt = $conn->prepare($updateSql);
        $updStmt->bind_param("i", $asset_id);
        $updStmt->execute();
        $updStmt->close();
    }
    $fkStmt->close();

    // ✅ 5) Delete from asset_history (if applicable)
    if ($conn->query("SHOW TABLES LIKE 'asset_history'")->num_rows > 0) {
        $delHistory = $conn->prepare("DELETE FROM asset_history WHERE asset_id = ?");
        $delHistory->bind_param("i", $asset_id);
        $delHistory->execute();
        $delHistory->close();
    }

    // ✅ 6) Delete the asset itself
    $delAsset = $conn->prepare("DELETE FROM assets WHERE asset_id = ?");
    $delAsset->bind_param("i", $asset_id);
    $delAsset->execute();

    if ($delAsset->affected_rows === 0) {
        $delAsset->close();
        $conn->rollback();
        header("Location: view_assets.php?msg=error&err=no_rows_deleted");
        exit();
    }
    $delAsset->close();

    // ✅ 7) Commit
    $conn->commit();
    $conn->close();

    // Redirect with success
    header("Location: view_assets.php?msg=deleted");
    exit();

} catch (Exception $e) {
    if ($conn->in_transaction) $conn->rollback();
    $msg = urlencode($e->getMessage());
    header("Location: view_assets.php?msg=error&err={$msg}");
    exit();
}
?>
