
<?php
session_start();
include 'db.php';

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

if (isset($_GET['id'])) {
    $asset_id = intval($_GET['id']);

    // Fetch asset details
    $stmt = $conn->prepare("SELECT * FROM assets WHERE asset_id = ?");
    $stmt->bind_param("i", $asset_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $asset = $result->fetch_assoc();
    $stmt->close();

    if (!$asset) {
        die("❌ Asset not found.");
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $asset_id = intval($_POST['asset_id']);
    $asset_name = $_POST['asset_name'];
    $asset_type = $_POST['asset_type'];
    $asset_status = $_POST['asset_status'];
    $asset_description = $_POST['asset_description'];

    // ✅ Correct update query
    $stmt = $conn->prepare("UPDATE assets 
                            SET asset_name=?, asset_type=?, asset_status=?, asset_description=? 
                            WHERE asset_id=?");
    $stmt->bind_param("ssssi", $asset_name, $asset_type, $asset_status, $asset_description, $asset_id);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: view_assets.php?msg=updated");
        exit();
    } else {
        echo "❌ Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Asset - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * { box-sizing: border-box; font-family: 'Poppins', sans-serif; }
    body { margin:0; padding:0; background:linear-gradient(to bottom right,#001f3f,#003366); min-height:100vh; display:flex; justify-content:center; align-items:center; color:#fff; }
    .form-container { background:rgba(255,255,255,0.07); backdrop-filter:blur(10px); padding:40px; border-radius:20px; width:100%; max-width:500px; box-shadow:0 10px 30px rgba(0,0,0,0.35); border:1px solid rgba(255,255,255,0.1); }
    .form-container h2 { text-align:center; margin-bottom:30px; color:#00d4ff; font-weight:600; }
    label { display:block; margin-top:15px; font-weight:500; color:rgba(244,236,236,0.79); }
    input[type="text"], select, textarea { width:100%; padding:12px; margin-top:6px; border-radius:8px; font-size:15px; background:rgba(255,255,255,0.3); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,0.3); color:#000; }
    input:focus, select:focus, textarea:focus { outline:none; background:#f6f4f4; box-shadow:0 0 0 2px #00d4ff; }
    select { appearance:none; background-image:url("data:image/svg+xml;charset=UTF-8,%3Csvg width='14' height='10' viewBox='0 0 14 10' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7 10L0.937822 0.25L13.0622 0.25L7 10Z' fill='%23000000'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; background-size:12px; }
    textarea { resize:vertical; min-height:80px; }
    .btn-submit { width:100%; margin-top:25px; background-color:#ff7f50; color:white; border:none; padding:14px; font-size:1em; font-weight:bold; border-radius:10px; cursor:pointer; transition:background 0.3s ease; }
    .btn-submit:hover { background-color:#ff5e1a; }
    .back-link { margin-top:25px; text-align:center; }
    .back-link a { color:#00d4ff; font-weight:500; text-decoration:none; }
    .back-link a:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <div class="form-container">
    <h2><i class="fas fa-edit"></i> Edit Asset</h2>
    <form method="POST">
      <input type="hidden" name="asset_id" value="<?= $asset['asset_id'] ?>">

      <label for="asset_name">Asset Name</label>
      <input type="text" name="asset_name" id="asset_name" 
             value="<?= htmlspecialchars($asset['asset_name']) ?>" required>

      <label for="asset_type">Asset Type</label>
      <input type="text" name="asset_type" id="asset_type" 
             value="<?= htmlspecialchars($asset['asset_type']) ?>" required>

      <label for="asset_status">Status</label>
      <select name="asset_status" id="asset_status" required>
        <option value="">-- Select Status --</option>
        <option value="available" <?= $asset['asset_status'] === 'available' ? 'selected' : ''; ?>>Available</option>
        <option value="allocated" <?= $asset['asset_status'] === 'allocated' ? 'selected' : ''; ?>>Allocated</option>
        <option value="under_maintenance" <?= $asset['asset_status'] === 'under_maintenance' ? 'selected' : ''; ?>>Under Maintenance</option>
      </select>

      <label for="asset_description">Description</label>
      <textarea name="asset_description" id="asset_description" placeholder="Enter optional description..."><?= htmlspecialchars($asset['asset_description']) ?></textarea>

      <button type="submit" class="btn-submit">💾 Update Asset</button>
    </form>

    <div class="back-link">
      <a href="view_assets.php"><i class="fas fa-arrow-left"></i> Back to Assets</a>
    </div>
  </div>
</body>
</html>
