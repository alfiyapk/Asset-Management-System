<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle approve/reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['request_id'];
    $action = $_POST['action'];

    if (in_array($action, ['Approved', 'Rejected'])) {
        $stmt = $conn->prepare("UPDATE asset_requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $action, $id);
        $stmt->execute();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Asset Requests</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <style>
        body {
            background: #0f172a;
            color: #fff;
            font-family: 'Poppins', sans-serif;
            padding: 40px;
        }

        h2 {
            text-align: center;
            color: #38bdf8;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        th {
            background: rgba(255,255,255,0.1);
            color: #f1f5f9;
        }

        td {
            color: #e2e8f0;
        }

        .action-btn {
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: bold;
            border: none;
            cursor: pointer;
            color: white;
            transition: background 0.3s;
        }

        .approve {
            background: #16a34a;
        }

        .approve:hover {
            background: #15803d;
        }

        .reject {
            background: #dc2626;
        }

        .reject:hover {
            background: #b91c1c;
        }

        .status {
            font-weight: 600;
            border-radius: 6px;
            padding: 5px 10px;
        }

        .Pending {
            background-color: #f59e0b;
            color: white;
        }

        .Approved {
            background-color: #22c55e;
            color: white;
        }

        .Rejected {
            background-color: #ef4444;
            color: white;
        }

        .back {
            text-align: center;
            margin-top: 20px;
        }

        .back a {
            color: #60a5fa;
            text-decoration: none;
            font-weight: 500;
        }

        .back a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>📝 Asset Request Management</h2>

    <table>
        <thead>
            <tr>
                <th>Request ID</th>
                <th>User ID</th>
                <th>Asset Name</th>
                <th>Description</th>
                <th>Requested On</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = $conn->query("SELECT * FROM asset_requests ORDER BY request_date DESC");

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['user_id']}</td>
                        <td>" . htmlspecialchars($row['asset_name']) . "</td>
                        <td>" . htmlspecialchars($row['description']) . "</td>
                        <td>" . date("d M Y h:i A", strtotime($row['request_date'])) . "</td>
                        <td>";

                if ($row['status'] === 'Pending') {
                    echo "<form method='POST' style='display:inline;'>
                            <input type='hidden' name='request_id' value='{$row['id']}'>
                            <input type='submit' name='action' value='Approved' class='action-btn approve'>
                          </form>
                          <form method='POST' style='display:inline; margin-left:5px;'>
                            <input type='hidden' name='request_id' value='{$row['id']}'>
                            <input type='submit' name='action' value='Rejected' class='action-btn reject'>
                          </form>";
                } else {
                    echo "<span class='status {$row['status']}'>" . $row['status'] . "</span>";
                }

                echo "</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="back">
        <a href="admin_dashboard.php">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
