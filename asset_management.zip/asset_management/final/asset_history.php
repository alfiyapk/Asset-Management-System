<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Asset History | Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      padding: 40px 20px;
      background: linear-gradient(to bottom right, #0f172a, #1e293b);
      font-family: 'Poppins', sans-serif;
      color: #fff;
    }

    h2 {
      text-align: center;
      color: #38bdf8;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255,255,255,0.05);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
    }

    th, td {
      padding: 12px 15px;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    th {
      background: rgba(255,255,255,0.1);
      color: #f8fafc;
    }

    td {
      color: #e2e8f0;
    }

    .badge {
      padding: 4px 10px;
      border-radius: 8px;
      font-size: 0.85rem;
      font-weight: bold;
      display: inline-block;
    }

    .assigned {
      background-color: #0ea5e9;
      color: #fff;
    }

    .returned {
      background-color: #22c55e;
      color: #fff;
    }

    .back {
      text-align: center;
      margin-top: 20px;
    }

    .back a {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 500;
    }

    .back a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <h2>📜 Asset Assignment & Return History</h2>

  <table>
    <thead>
      <tr>
        <th>User ID</th>
        <th>User Name</th>
        <th>Asset ID</th>
        <th>Asset Name</th>
        <th>Assigned Date</th>
        <th>Returned Date</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // 1. Assigned Assets (not returned)
      $sql1 = "SELECT aa.user_id, u.name AS user_name, a.asset_id, a.asset_name, aa.assigned_date
               FROM assigned_assets aa
               JOIN users u ON aa.user_id = u.user_id
               JOIN assets a ON aa.asset_id = a.asset_id";

      $res1 = $conn->query($sql1);
      while ($row = $res1->fetch_assoc()) {
          echo "<tr>
                  <td>{$row['user_id']}</td>
                  <td>" . htmlspecialchars($row['user_name']) . "</td>
                  <td>{$row['asset_id']}</td>
                  <td>" . htmlspecialchars($row['asset_name']) . "</td>
                  <td>" . date("d M Y", strtotime($row['assigned_date'])) . "</td>
                  <td>-</td>
                  <td><span class='badge assigned'>Assigned</span></td>
                </tr>";
      }

      // 2. Returned Assets
      $sql2 = "SELECT ra.user_id, u.name AS user_name, a.asset_id, a.asset_name, ra.assigned_at, ra.returned_at
               FROM returned_assets ra
               JOIN users u ON ra.user_id = u.user_id
               JOIN assets a ON ra.asset_id = a.asset_id";

      $res2 = $conn->query($sql2);
      while ($row = $res2->fetch_assoc()) {
          echo "<tr>
                  <td>{$row['user_id']}</td>
                  <td>" . htmlspecialchars($row['user_name']) . "</td>
                  <td>{$row['asset_id']}</td>
                  <td>" . htmlspecialchars($row['asset_name']) . "</td>
                  <td>" . date("d M Y", strtotime($row['assigned_at'])) . "</td>
                  <td>" . date("d M Y", strtotime($row['returned_at'])) . "</td>
                  <td><span class='badge returned'>Returned</span></td>
                </tr>";
      }
      ?>
    </tbody>
  </table>
 <div style="margin-top:40px; text-align:center;">
    <a href="admin_dashboard.php" 
       style="background:#2563eb; color:#fff; padding:10px 16px; border-radius:8px; 
              text-decoration:none; font-weight:600; transition:0.3s;">
      ⬅ Back to Dashboard
    </a>
  </div>
  
</body>
</html>
