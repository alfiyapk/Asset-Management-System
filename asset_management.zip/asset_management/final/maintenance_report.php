
<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Fetch all requests
$sql = "SELECT m.*, u.name AS user_name, a.asset_name 
        FROM maintenance_requests m 
        JOIN users u ON m.user_id = u.user_id 
        JOIN assets a ON m.asset_id = a.asset_id
        ORDER BY m.request_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Maintenance Report</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; font-family: 'Poppins', sans-serif; }

    body {
      margin: 0;
      padding: 30px;
      background: #0f172a;
      color: #fff;
    }

    .container {
      max-width: 1100px;
      margin: auto;
      background: rgba(255,255,255,0.05);
      padding: 30px;
      border-radius: 16px;
      backdrop-filter: blur(10px);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    }

    /* Report Header */
    .report-header {
      text-align: center;
      border-bottom: 2px solid #38bdf8;
      padding-bottom: 20px;
      margin-bottom: 25px;
    }

    .report-header img {
      max-height: 70px;
      margin-bottom: 10px;
    }

    .company-name {
      font-size: 1.5rem;
      font-weight: 700;
      color: #38bdf8;
    }

    .company-details {
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .report-title {
      margin-top: 15px;
      font-size: 1.3rem;
      font-weight: 600;
      color: #facc15;
    }

    .report-date {
      font-size: 0.9rem;
      margin-top: 5px;
      color: #94a3b8;
    }

    h2 {
      text-align: center;
      color: #38bdf8;
      margin-bottom: 20px;
    }

    select, button, input[type="date"] {
      padding: 10px 16px;
      font-weight: 500;
      border-radius: 8px;
      border: none;
      margin-right: 10px;
    }

    table {
      width: 100%;
      margin-top: 20px;
      border-collapse: collapse;
    }

    th, td {
      padding: 12px;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    th {
      background: #2563eb;
      color: #fff;
      text-transform: uppercase;
    }

    .export-btn {
      background-color: #10b981;
      color: white;
      font-weight: 600;
      cursor: pointer;
    }

    .pdf-btn {
      background-color: #9333ea;
      color: white;
    }

    .status {
      font-weight: bold;
      padding: 6px 12px;
      border-radius: 8px;
    }

    .pending { background-color: #facc15; color: #1f2937; }
    .in_progress { background-color: #3b82f6; color: #fff; }
    .completed { background-color: #10b981; color: #fff; }

    @media (max-width: 768px) {
      table { font-size: 0.9rem; }
      .filters { flex-direction: column; gap: 10px; }
    }
  </style>
</head>
<body>
<div class="container">

  <!-- Report Header -->
  <div class="report-header">
    <img src="companylogo.png" alt="Company Logo"> <!-- replace with your logo path -->
    
    <div class="company-details">
      Kacheripady, Muvattupuzha, Kerala 686673  <br>
      Email: info@www.safecaretec.in | Phone: +91 098471 84455
    </div>
    <div class="report-title">📊 Maintenance Request Report</div>
    <div class="report-date">Generated on: <?= date("d M Y, h:i A"); ?></div>
  </div>

  <!-- Filters -->
  <div class="filters" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
    <div>
      <label for="statusFilter"><strong>Status:</strong></label>
      <select id="statusFilter" onchange="applyFilters()">
        <option value="all">All</option>
        <option value="pending">Pending</option>
        <option value="in_progress">In Progress</option>
        <option value="completed">Completed</option>
      </select>

      <label><strong>From:</strong></label>
      <input type="date" id="startDate" onchange="applyFilters()">

      <label><strong>To:</strong></label>
      <input type="date" id="endDate" onchange="applyFilters()">
    </div>

    <div>
      <button onclick="exportToExcel()" class="export-btn">📥 Export Excel</button>
      <button onclick="exportToPDF()" class="export-btn pdf-btn">📄 Export PDF</button>
    </div>
  </div>

  <!-- Table -->
  <table id="reportTable">
    <thead>
      <tr>
        <th>ID</th>
        <th>User</th>
        <th>Asset</th>
        <th>Issue</th>
        <th>Date</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
    <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= $row['request_id']; ?></td>
        <td><?= htmlspecialchars($row['user_name']); ?></td>
        <td><?= htmlspecialchars($row['asset_name']); ?></td>
        <td><?= htmlspecialchars($row['issue_description']); ?></td>
        <td data-date="<?= date("Y-m-d", strtotime($row['request_date'])); ?>">
            <?= date("d M Y, h:i A", strtotime($row['request_date'])); ?>
        </td>
        <td><span class="status <?= $row['status']; ?>"><?= ucwords(str_replace('_',' ', $row['status'])); ?></span></td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>

<!-- SheetJS (Excel) -->
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>

<!-- jsPDF & AutoTable (PDF) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>

<script>
  function applyFilters() {
    const statusFilter = document.getElementById('statusFilter').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;

    const rows = document.querySelectorAll("#reportTable tbody tr");
    rows.forEach(row => {
      const status = row.querySelector("td:last-child .status").classList[1];
      const date = row.querySelector("td[data-date]").getAttribute("data-date");

      let show = true;

      if (statusFilter !== "all" && status !== statusFilter) {
        show = false;
      }
      if (startDate && date < startDate) {
        show = false;
      }
      if (endDate && date > endDate) {
        show = false;
      }

      row.style.display = show ? "" : "none";
    });
  }

  function exportToExcel() {
    const table = document.getElementById("reportTable");
    const wb = XLSX.utils.table_to_book(table, { sheet: "Maintenance Report" });
    XLSX.writeFile(wb, "maintenance_report.xlsx");
  }
async function exportToPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF("p", "pt", "a4");

    // Colors
    const primaryColor = [37, 99, 235];  // Blue
    const secondaryColor = [56, 189, 248]; // Light Blue

    // --- Header Banner ---
    doc.setFillColor(...primaryColor);
    doc.rect(0, 0, doc.internal.pageSize.getWidth(), 80, "F");

    // ✅ Bigger Logo (size: 60x60 instead of 40x40)
    const logo = "data:image/png;base64,<?= base64_encode(file_get_contents('companylogo.png')); ?>";
    doc.addImage(logo, "PNG", 70, 10, 120, 60);

    // ✅ Company Info (moved further right → x = 140 instead of 120)
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.text("SafeCare Technologies Pvt. Ltd.", 230,35);

    doc.setFontSize(10);
    doc.text("Kacheripady, Muvattupuzha, Kerala 686673", 250, 50);
    doc.text("Email: info@www.safecaretec.in | Phone: +91 098471 84455", 220, 65);

    // --- Report Title (Centered + Divider) ---
    doc.setFontSize(16);
    doc.setTextColor(...secondaryColor);
    const pageWidth = doc.internal.pageSize.getWidth();
    const title = "Maintenance Request Report";
    const textWidth = doc.getTextWidth(title);
    const xPos = (pageWidth - textWidth) / 2;

    doc.text(title, xPos, 110);

    // Divider Line under Title
    doc.setDrawColor(...secondaryColor);
    doc.setLineWidth(1);
    doc.line(60, 120, pageWidth - 60, 120);

    // ✅ Date (centered below divider)
    doc.setFontSize(10);
    doc.setTextColor(100);
    const dateText = "Generated on: <?= date('d M Y, h:i A'); ?>";
    const dateWidth = doc.getTextWidth(dateText);
    const dateX = (pageWidth - dateWidth) / 2;
    doc.text(dateText, dateX, 140);

    // --- Table ---
    doc.autoTable({
        html: "#reportTable",
        startY: 160,
        theme: "striped",
        headStyles: {
            fillColor: primaryColor,
            textColor: 255,
            fontSize: 10,
            halign: "center"
        },
        bodyStyles: {
            fontSize: 9,
            textColor: [50, 50, 50],
        },
        alternateRowStyles: {
            fillColor: [240, 248, 255]
        },
        styles: {
            cellPadding: 6,
            halign: "center",
            valign: "middle"
        },
        margin: { left: 40, right: 40 }
    });

    // --- Footer ---
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(9);
        doc.setTextColor(150);
        doc.text(
            `Page ${i} of ${pageCount}`,
            doc.internal.pageSize.getWidth() - 60,
            doc.internal.pageSize.getHeight() - 20
        );
        doc.text(
            "SafeCare Technologies • Reliable Asset & Maintenance Management",
            40,
            doc.internal.pageSize.getHeight() - 20
        );
    }

    doc.save("maintenance_report.pdf");
}


</script>

<div style="margin-top:40px; text-align:center;">
    <a href="admin_dashboard.php" 
       style="background:#2563eb; color:#fff; padding:10px 16px; border-radius:8px; 
              text-decoration:none; font-weight:600; transition:0.3s;">
      ⬅ Back to Dashboard
    </a>
</div>
</body>
</html>
