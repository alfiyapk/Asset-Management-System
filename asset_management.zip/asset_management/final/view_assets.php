
<?php
session_start();
include 'db.php';

// ✅ Only admins can view assets
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// ✅ Fetch all assets
$result = $conn->query("SELECT * FROM assets");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>View Assets - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    * { box-sizing: border-box; font-family: 'Poppins', sans-serif; }
    body {
      margin: 0; background: linear-gradient(to bottom right, #0f172a, #1e293b);
      color: #fff; min-height: 100vh; display: flex; flex-direction: column;
      align-items: center; padding: 20px;
    }
    h2 { margin: 30px 0; font-size: 2.2em; color: #38bdf8; text-align: center; }
    table {
      width: 95%; max-width: 1100px; border-collapse: collapse;
      background: rgba(255,255,255,0.05); border-radius: 12px;
      overflow: hidden; backdrop-filter: blur(10px);
      box-shadow: 0 10px 30px rgba(0,0,0,0.35);
    }
    th, td {
      padding: 14px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1);
      color: #f1f5f9; font-size: 0.95em;
    }
    th { background-color: #2563eb; color: white; }
    tr:hover { background-color: rgba(255, 255, 255, 0.08); }
    .action-btn {
      padding: 6px 12px; margin: 2px; border-radius: 8px; font-weight: 500;
      text-decoration: none; font-size: 0.9em; transition: all 0.3s ease; display: inline-block;
    }
    .edit { background: #22c55e; color: #fff; }
    .edit:hover { background: #16a34a; }
    .delete { background: #ef4444; color: white; }
    .delete:hover { background: #b91c1c; }
    .back { margin-top: 30px; }
    .back a { color: #38bdf8; text-decoration: none; font-weight: 600; }
    .back a:hover { text-decoration: underline; }
    @media (max-width: 768px) { table { font-size: 0.85em; } }
  </style>
</head>
<body>

  <h2>📋 Asset Management Overview</h2>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'updated'): ?>
    <div style="background:#16a34a; color:#fff; padding:12px; text-align:center; font-weight:bold; border-radius:5px; margin:15px auto; width:90%;">
      ✅ Asset details updated successfully!
    </div>
  <?php endif; ?>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
    <div style="background:#dc2626; color:#fff; padding:12px; text-align:center; font-weight:bold; border-radius:5px; margin:15px auto; width:90%;">
      🗑️ Asset deleted successfully!
    </div>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Asset Name</th>
        <th>Type</th>
        <th>Status</th>
        <th>Description</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= $row['asset_id']; ?></td>
        <td><?= htmlspecialchars($row['asset_name']); ?></td>
        <td><?= htmlspecialchars($row['asset_type']); ?></td>
        <td><?= htmlspecialchars($row['asset_status']); ?></td>
        <td><?= htmlspecialchars($row['asset_description']); ?></td>
        <td>
          <a href="edit_asset.php?id=<?= $row['asset_id']; ?>" class="action-btn edit"><i class="fas fa-pen"></i> Edit</a>
          <a href="delete_asset.php?asset_id=<?= $row['asset_id']; ?>" 
             class="action-btn delete"
             onclick="return confirm('Are you sure you want to delete this asset?');">
             <i class="fas fa-trash"></i> Delete
          </a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>

  <div class="back">
    <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
  </div>

</body>
</html>
