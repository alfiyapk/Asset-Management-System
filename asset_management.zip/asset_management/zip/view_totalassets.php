<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

$result = $conn->query("SELECT * FROM assets");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Assets - Admin Panel</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background: #0d1b2a;
      color: #fff;
      padding: 40px;
      min-height: 100vh;
    }

    h2 {
      margin-bottom: 30px;
      font-size: 28px;
      color: #00c6ff;
      text-align: center;
    }

    h2 i {
      margin-right: 8px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(15, 30, 50, 0.85);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 8px 25px rgba(0,0,0,0.4);
    }

    thead {
      background-color: #007BFF;
    }

    thead th {
      color: white;
      padding: 14px;
      text-align: left;
      font-size: 15px;
    }

    tbody tr {
      border-bottom: 1px solid #2e3a59;
      transition: background 0.2s;
    }

    tbody tr:hover {
      background-color: rgba(255, 255, 255, 0.05);
    }

    tbody td {
      padding: 12px 14px;
      color: #dcdcdc;
    }

    .back {
      margin-top: 40px;
      text-align: center;
    }

    .back a {
      display: inline-block;
      background: #00c6ff;
      color: white;
      padding: 10px 20px;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(0, 198, 255, 0.3);
      transition: all 0.3s ease;
    }

    .back a:hover {
      background: #009ad6;
      box-shadow: 0 6px 16px rgba(0, 198, 255, 0.5);
    }

    .back a i {
      margin-right: 6px;
    }

    @media (max-width: 768px) {
      table, thead, tbody, th, td, tr {
        display: block;
      }

      thead {
        display: none;
      }

      tbody tr {
        margin-bottom: 15px;
        border-radius: 10px;
        padding: 10px;
        background: rgba(20, 30, 50, 0.85);
        border: 1px solid #2e3a59;
      }

      tbody td {
        padding-left: 50%;
        position: relative;
        text-align: left;
      }

      tbody td::before {
        position: absolute;
        left: 15px;
        top: 12px;
        font-weight: bold;
        color: #aaa;
      }

      tbody td:nth-of-type(1)::before { content: "Asset ID"; }
      tbody td:nth-of-type(2)::before { content: "Name"; }
      tbody td:nth-of-type(3)::before { content: "Type"; }
      tbody td:nth-of-type(4)::before { content: "Status"; }
      tbody td:nth-of-type(5)::before { content: "Description"; }
    }
  </style>
</head>
<body>

<h2><i class="fas fa-box-open"></i> All Assets in the Company</h2>

<table>
  <thead>
    <tr>
      <th>Asset ID</th>
      <th>Name</th>
      <th>Type</th>
      <th>Status</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['asset_id']) ?></td>
        <td><?= htmlspecialchars($row['asset_name']) ?></td>
        <td><?= htmlspecialchars($row['asset_type']) ?></td>
        <td><?= htmlspecialchars($row['asset_status']) ?></td>
        <td><?= htmlspecialchars($row['description']) ?></td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<div class="back">
  <a href="admin_dashboard.php"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
</div>

</body>
</html>
