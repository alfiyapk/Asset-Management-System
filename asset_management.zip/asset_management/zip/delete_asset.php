<?php
// debug + strict mysqli errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

session_start();
include 'db.php';

// only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

if (!isset($_GET['asset_id'])) {
    header("Location: view_assets.php?msg=invalid");
    exit();
}

$asset_id = intval($_GET['asset_id']);
$admin_id = intval($_SESSION['user_id']);

try {
    // start transaction
    $conn->begin_transaction();

    // 1) check asset exists
    $chk = $conn->prepare("SELECT asset_id FROM assets WHERE asset_id = ?");
    $chk->bind_param("i", $asset_id);
    $chk->execute();
    $res = $chk->get_result();
    if ($res->num_rows === 0) {
        $chk->close();
        $conn->rollback();
        header("Location: view_assets.php?msg=notfound");
        exit();
    }
    $chk->close();

    // 2) ensure deletion log table exists (preserve deletion record)
    $createLogTable = "
        CREATE TABLE IF NOT EXISTS asset_deletion_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            asset_id INT NOT NULL,
            admin_id INT NULL,
            note TEXT,
            deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";
    $conn->query($createLogTable);

    // insert deletion log (separate table so it isn't removed by cascade)
    $note = "Asset deleted by Admin (User ID: {$admin_id})";
    $ins = $conn->prepare("INSERT INTO asset_deletion_log (asset_id, admin_id, note) VALUES (?, ?, ?)");
    $ins->bind_param("iis", $asset_id, $admin_id, $note);
    $ins->execute();
    $ins->close();

    // 3) find foreign-key referencing tables (so we delete dependent rows first)
    $dbRow = $conn->query("SELECT DATABASE()")->fetch_row();
    $dbName = $dbRow[0] ?? '';

    $fkStmt = $conn->prepare("
        SELECT TABLE_NAME, COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE REFERENCED_TABLE_NAME = 'assets'
          AND REFERENCED_TABLE_SCHEMA = ?
    ");
    $fkStmt->bind_param("s", $dbName);
    $fkStmt->execute();
    $fkRes = $fkStmt->get_result();

    while ($fkRow = $fkRes->fetch_assoc()) {
        $table = $fkRow['TABLE_NAME'];
        $column = $fkRow['COLUMN_NAME'];

        // basic validation of identifier names
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) {
            throw new Exception("Invalid table/column name found in FK list: {$table}.{$column}");
        }

        // delete dependent rows from the referencing table
        $delSql = "DELETE FROM `{$table}` WHERE `{$column}` = ?";
        $delStmt = $conn->prepare($delSql);
        $delStmt->bind_param("i", $asset_id);
        $delStmt->execute();
        $delStmt->close();
    }
    $fkStmt->close();

    // 4) delete asset_history rows for this asset (if any)
    $delHistory = $conn->prepare("DELETE FROM asset_history WHERE asset_id = ?");
    $delHistory->bind_param("i", $asset_id);
    $delHistory->execute();
    $delHistory->close();

    // 5) finally delete the asset
    $delAsset = $conn->prepare("DELETE FROM assets WHERE asset_id = ?");
    $delAsset->bind_param("i", $asset_id);
    $delAsset->execute();

    // optionally check affected_rows to ensure deletion happened
    if ($delAsset->affected_rows === 0) {
        // no rows removed — something unexpected
        $delAsset->close();
        $conn->rollback();
        header("Location: view_assets.php?msg=error&err=no_rows_deleted");
        exit();
    }
    $delAsset->close();

    // commit everything
    $conn->commit();
    $conn->close();

    header("Location: view_assets.php?msg=deleted");
    exit();

} catch (Exception $e) {
    // rollback and show short error code (URL-encoded message)
    if ($conn->in_transaction) $conn->rollback();
    $msg = urlencode($e->getMessage());
    // you can display the raw error during development by using ?err=...
    header("Location: view_assets.php?msg=error&err={$msg}");
    exit();
}
?>
