
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'db.php';
date_default_timezone_set('Asia/Kolkata');

// ✅ Admin-only access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// ✅ Handle filter
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// ✅ Base query
$sql = "SELECT * FROM activities WHERE 1=1";
if (!empty($startDate) && !empty($endDate)) {
    $sql .= " AND activity_time BETWEEN '$startDate' AND '$endDate'";
}
$sql .= " ORDER BY activity_time DESC";
$result = $conn->query($sql);

// ✅ Export to Excel
if (isset($_GET['export']) && $_GET['export'] === 'excel') {
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=activity_report.xls");
    echo "ID\tUser\tAction\tDetails\tTime\n";
    while ($row = $result->fetch_assoc()) {
        echo $row['activity_id'] . "\t" . $row['user_id'] . "\t" . $row['action'] . "\t" . $row['details'] . "\t" . $row['activity_time'] . "\n";
    }
    exit();
}

// ✅ Export to PDF
if (isset($_GET['export']) && $_GET['export'] === 'pdf') {
    require('fpdf/fpdf.php'); // ✅ Make sure you have FPDF library in project folder

    class PDF extends FPDF {
        function Header() {
            $this->SetFont('Arial','B',12);
            $this->Cell(0,10,'Activity Report',0,1,'C');
            $this->Ln(5);
        }
    }

    $pdf = new PDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',10);

    // Table Header
    $pdf->Cell(20,10,"ID",1);
    $pdf->Cell(30,10,"User",1);
    $pdf->Cell(40,10,"Action",1);
    $pdf->Cell(60,10,"Details",1);
    $pdf->Cell(40,10,"Time",1);
    $pdf->Ln();

    $pdf->SetFont('Arial','',9);
    $res = $conn->query($sql);
    while ($row = $res->fetch_assoc()) {
        $pdf->Cell(20,10,$row['activity_id'],1);
        $pdf->Cell(30,10,$row['user_id'],1);
        $pdf->Cell(40,10,$row['action'],1);
        $pdf->Cell(60,10,substr($row['details'],0,30),1);
        $pdf->Cell(40,10,$row['activity_time'],1);
        $pdf->Ln();
    }

    $pdf->Output("D","activity_report.pdf");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Activity Report</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body {
            background: #121212;
            color: #fff;
            font-family: Arial, sans-serif;
        }
        .card {
            background: rgba(255,255,255,0.05);
            border: none;
            border-radius: 12px;
            padding: 20px;
            margin-top: 20px;
        }
        .btn-custom {
            background: #0d6efd;
            color: #fff;
            border-radius: 8px;
            padding: 8px 16px;
        }
        .btn-custom:hover {
            background: #0b5ed7;
        }
        table {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
        }
        th {
            color: #0dcaf0;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <h2 class="text-center mb-4">📊 Activity Report</h2>

    <!-- Filter Form -->
    <div class="card">
        <form method="GET" class="row g-3">
            <div class="col-md-5">
                <label class="form-label">From Date</label>
                <input type="date" name="start_date" class="form-control" value="<?= $startDate ?>">
            </div>
            <div class="col-md-5">
                <label class="form-label">To Date</label>
                <input type="date" name="end_date" class="form-control" value="<?= $endDate ?>">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-custom w-100">Filter</button>
            </div>
        </form>
    </div>

    <!-- Export Buttons -->
    <div class="mt-3">
        <a href="?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>&export=excel" class="btn btn-success me-2">Export to Excel</a>
        <a href="?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>&export=pdf" class="btn btn-danger">Export to PDF</a>
    </div>

    <!-- Report Table -->
    <div class="card mt-4">
        <h5>All Activities</h5>
        <table class="table table-dark table-hover mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['activity_id'] ?></td>
                        <td><?= $row['user_id'] ?></td>
                        <td><?= $row['action'] ?></td>
                        <td><?= $row['details'] ?></td>
                        <td><?= $row['activity_time'] ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">No activities found</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>

