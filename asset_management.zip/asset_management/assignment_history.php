<?php
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

if ($role == 'admin') {
    $query = "SELECT aa.assigned_at, u.name AS user_name, a.asset_name 
              FROM assigned_assets aa
              JOIN users u ON aa.user_id = u.user_id 
              JOIN assets a ON aa.asset_id = a.asset_id 
              ORDER BY aa.assigned_at DESC";
    $stmt = $conn->prepare($query);
} else {
    $query = "SELECT aa.assigned_at, a.asset_name 
              FROM assigned_assets aa
              JOIN assets a ON aa.asset_id = a.asset_id 
              WHERE aa.user_id = ? 
              ORDER BY aa.assigned_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
}

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Asset Assignment History</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    
     <style>
           body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(to right, #d3cce3, #e9e4f0);
            padding: 40px 20px;
            margin: 0;
            color: #333;
        }

        .container {
            max-width: 1050px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: 600;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 30px;
        }

        th, td {
            padding: 14px 18px;
            text-align: center;
            border-bottom: 1px solid #e2e2e2;
        }

        th {
            background-color: #3f51b5;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #eef2ff;
        }

        .back {
            text-align: center;
        }

        .back a {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #3f51b5;
            color: #fff;
            border-radius: 8px;
            font-weight: 500;
            transition: background-color 0.3s;
        }

        .back a:hover {
            background-color: #2c387e;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 0.9em;
            }

            .container {
                padding: 20px;
            }
        }
    </style>
      
</head>
<body>
    <div class="container">
        <h2>📋 Asset Assignment History</h2>
        <table>
            <thead>
                <tr>
                    <th>Asset Name</th>
                    <?php if ($role === 'admin') echo '<th>Assigned To</th>'; ?>
                    <th>Assigned On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= htmlspecialchars($row['asset_name']) ?></td>
                        <?php if ($role === 'admin') echo '<td>' . htmlspecialchars($row['user_name']) . '</td>'; ?>
                        <td><?= date("d M Y, h:i A", strtotime($row['assigned_at'])) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <div class="back">
            <a href="<?= $role === 'admin' ? 'admin_dashboard.php' : 'user_dashboard.php' ?>">⬅ Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
